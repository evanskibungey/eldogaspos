#!/bin/bash
# Fingerprints every PHP/Blade source file under the app root.
#
# Line endings are normalised before hashing (tr -d '\r'), because a Windows
# checkout stores CRLF and a Linux server stores LF - without this every single
# file would falsely report as different.
#
# Run from the Laravel app root. Same command works on Windows (Git Bash) and
# on the cPanel server, so the two outputs are directly comparable.

find app resources routes config database/migrations database/seeders \
     -type f \( -name '*.php' -o -name '*.blade.php' \) 2>/dev/null \
| sort \
| while IFS= read -r f; do
    printf '%s  %s\n' "$(tr -d '\r' < "$f" | md5sum | cut -d' ' -f1)" "$f"
done
