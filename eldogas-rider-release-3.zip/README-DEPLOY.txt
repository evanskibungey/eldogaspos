EldoGas POS - Quick sale + rider delivery allocation (release 3)   2026-09-18
==============================================================================

Target:   sales.eldogas.co.ke   (cPanel)
App root: ~/domains/sales.eldogas.co.ke/eldogaspos
Web root: ~/domains/sales.eldogas.co.ke/public_html

------------------------------------------------------------------------------
READ THIS FIRST - THIS RELEASE CHANGES HOW CASHIERS TAKE A SALE
------------------------------------------------------------------------------
This is NOT only the rider feature. Release 2 shipped the SMS copy change and
nothing since, so the quick-sale rework is still sitting undeployed and goes
out with this release. On the morning after this deploy, every cashier's screen
behaves differently:

  THE CART IS GONE.
      One tap on a product tile completes the whole sale - no cart, no review
      screen, no confirm dialog, no payment modal. It is cash, paid, done.
  DOUBLE TAP SELLS AND PRINTS.
      The second tap prints the receipt directly. There is no print preview.
  QUANTITY IS SET ON THE TILE.
      The - and + stepper on each tile sets how many before you tap to sell.

Tell the till staff BEFORE this goes out, not after. A cashier who taps a tile
expecting to "add to cart" has already made a sale. It is reversible - Sales
History -> Void returns the stock - but it is a real sale until voided.

Two protections exist because that confirm step is gone:
  - Every tap carries a one-time key. A double-click, an impatient second tap
    or a retried request on a flaky connection returns the sale already made
    instead of taking money twice. The database enforces this, not the browser.
  - The order number and stock figures come from the same locked read that did
    the deduction, so two tills cannot sell the same cylinder.

------------------------------------------------------------------------------
WHAT ELSE IS NEW - RIDER DELIVERY ALLOCATION
------------------------------------------------------------------------------
  A "Pick-up" button on every POS product tile hands cylinders to a delivery
  rider instead of selling them. Tap it, tap a rider, done - the rider is
  texted what to collect and the reference to complete against.

  Stock and money are deliberately separated:
      Pick-up      RESERVES the cylinders. Availability drops immediately so
                   the same cylinder cannot be sold at the till, but physical
                   stock is untouched and NO SALE EXISTS YET. Cylinders on a
                   bike are not revenue - they can come back unsold.
      Complete     Admin clicks this when the rider returns. Only now is the
                   stock deducted for real and a paid cash sale written.
      Cancel       Puts the cylinders straight back into sellable stock. No
                   sale is recorded.

  New section "Rider Cylinders" in the sidebar, under Cylinder Management,
  reachable by both admins (/admin/riders) and cashiers (/pos/riders).
  Add riders there first - until a rider exists the picker says so.

  Two SMS, both one billed segment, sent through the existing TalkSasa
  service. No new gateway settings, no new credentials, no queue worker:
      on pick-up    Pick-up #RDR20260918001
                    3x 13kg Gas Cylinder
      on complete   Order #RDR20260918001 has been completed successfully.
                    Thank you.

  The completion text is stamped against the order once it is sent, so
  completing twice, a retried request or a double-submit cannot buy a second
  message.

------------------------------------------------------------------------------
DATABASE CHANGES - UNLIKE RELEASE 2, THIS ONE HAS THEM
------------------------------------------------------------------------------
  Four migrations. None of them touch existing rows.

    2026_09_18_000001_add_idempotency_key_to_sales
        Adds one nullable column + unique index to `sales`. Existing sales get
        NULL; MySQL permits many NULLs in a unique index, so nothing conflicts.
        This is an ALTER on your largest table - it holds a brief lock, which
        is why step 4 uses maintenance mode.
    2026_09_18_000002_create_riders_table
    2026_09_18_000003_create_rider_allocations_table
    2026_09_18_000004_create_rider_allocation_items_table
        Three new tables. Nothing existing is read or written.

  Take the database backup in step 1 anyway. It costs a minute.

  NEVER on production: migrate:fresh, migrate:refresh, migrate:reset,
  db:wipe, db:seed. Any one of them destroys live sales.

------------------------------------------------------------------------------
ASSETS - THE SERVICE WORKER CACHE IS BUMPED THIS TIME
------------------------------------------------------------------------------
  Markup and CSS both changed, so public_html/sw.js moves from
  eldogas-pos-v3-20260911 to eldogas-pos-v4-20260918. Without that bump a till
  with the service worker active keeps serving the OLD cached /pos/dashboard
  and would never show the Pick-up button.

  After deploying, each till still needs one reload to pick the new worker up.

DELIBERATELY NOT INCLUDED - do not add these
  .env                  the server keeps its own
  vendor/               no dependency changes
  database/seeders/     would duplicate the live catalogue if db:seed ran
  storage/              live runtime data
  public/hot            dev-server marker; shipping it breaks every asset URL
  public_html/index.php production's copy points at ../eldogaspos
  public_html/.htaccess cPanel may have added PHP-version handlers to it
  tests/, phpunit.xml   NEVER run tests on production

==============================================================================
STEP 1 - BACK UP CODE AND DATABASE
==============================================================================
    cd ~/domains/sales.eldogas.co.ke
    tar --exclude='eldogaspos/vendor' --exclude='eldogaspos/node_modules' \
        --exclude='eldogaspos/storage/logs' \
        -czf ~/backup-code-$(date +%Y%m%d-%H%M).tar.gz eldogaspos public_html
    ls -lh ~/backup-code-*.tar.gz

  Database (this release has migrations, so take it):

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    DB=$(grep '^DB_DATABASE=' .env | cut -d= -f2)
    DU=$(grep '^DB_USERNAME=' .env | cut -d= -f2)
    mysqldump -u "$DU" -p "$DB" > ~/backup-db-$(date +%Y%m%d-%H%M).sql
    ls -lh ~/backup-db-*.sql

==============================================================================
STEP 2 - UNPACK INTO A HOLDING FOLDER
==============================================================================
  Upload eldogas-rider-release-3.zip to ~/domains/sales.eldogas.co.ke/ then:

    cd ~/domains/sales.eldogas.co.ke
    rm -rf release-staging
    unzip -q eldogas-rider-release-3.zip -d release-staging

    cp release-staging/eldogaspos/deploy-check.sh \
       release-staging/eldogaspos/baseline-manifest.txt \
       release-staging/eldogaspos/release-manifest.txt \
       eldogaspos/

==============================================================================
STEP 3 - THE CHECK  (read-only, changes nothing)
==============================================================================
    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    bash deploy-check.sh

  EXPECT EXACTLY:
      SAFE  will update: 7   will add: 11   already current: 215

  "RESULT: STOP"           -> someone edited files on the server since release
                              2. Send those files over to be merged first. Do
                              not extract over them.
  "RESULT: CHECK INVALID"  -> wrong folder, or a manifest was damaged.
  "RESULT: SAFE"           -> continue.

  If "will update" is not 7 or "will add" is not 11, stop and ask. The 18
  files this release touches are listed at the bottom of this file.

==============================================================================
STEP 4 - COPY IT IN AND MIGRATE
==============================================================================
  Use maintenance mode this time. There is a schema change on `sales`, and no
  cashier should be mid-sale while the POS screen is being swapped underneath
  them. The whole step is well under a minute.

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan down --secret="eldogas-deploy-check"

    cd ~/domains/sales.eldogas.co.ke
    cp -r release-staging/eldogaspos/.   eldogaspos/
    cp -r release-staging/public_html/.  public_html/

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan migrate --force

  Expect four lines ending DONE:
      2026_09_18_000001_add_idempotency_key_to_sales ............. DONE
      2026_09_18_000002_create_riders_table ..................... DONE
      2026_09_18_000003_create_rider_allocations_table .......... DONE
      2026_09_18_000004_create_rider_allocation_items_table ..... DONE

    php artisan config:clear && php artisan cache:clear
    php artisan view:clear   && php artisan route:clear
    php artisan up

==============================================================================
STEP 5 - VERIFY
==============================================================================
  a. The POS loads and sells on one tap. Open /pos/dashboard, hard-refresh
     (Ctrl+Shift+R) so the new service worker takes over, and confirm there is
     no cart panel and each tile has a - / + stepper and a Pick-up button.

     Sell one cheap item with a single tap. Check Sales History shows exactly
     ONE sale, and that stock fell by one - not two.

  b. Add a rider. Sidebar -> Rider Cylinders -> Add a rider. Use a phone you
     can read, in any spelling (07.. or 2547..) - it is normalised.

  c. Do a pick-up. On a product tile press Pick-up, then tap the rider. Expect
     the reference (RDR20260918nnn) on screen, an SMS on that phone, and the
     tile's stock to drop. Then confirm in Rider Cylinders that the order is
     Pending and the rider reads "Out on delivery".

  d. Complete it. Click Complete on that order. Expect the completion SMS, the
     rider back to "Available", and a new paid cash sale in Sales History for
     that amount.

  e. The old app link still works - messages already sent point at it:

       curl -sI https://sales.eldogas.co.ke/app | grep -iE "^HTTP|^location"

     Expect 302 to the Play Store.

  f. Re-run the check - everything should now be current:

       cd ~/domains/sales.eldogas.co.ke/eldogaspos
       bash deploy-check.sh

     Expect: will update: 0   will add: 0   already current: 233

  g. Tidy up:

       cd ~/domains/sales.eldogas.co.ke && rm -rf release-staging

==============================================================================
IF SOMETHING GOES WRONG
==============================================================================
  ROLL BACK THE CODE, NOT THE DATABASE.

    cd ~/domains/sales.eldogas.co.ke
    ls -lh ~/backup-code-*.tar.gz          # the one from step 1
    tar -xzf ~/backup-code-YYYYMMDD-HHMM.tar.gz

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan config:clear && php artisan view:clear && php artisan route:clear
    php artisan up

  Leave the migrations in place. The restored release-2 code never references
  sales.idempotency_key (it is nullable, so inserts still work) and never
  touches the three rider tables - they simply sit unused. Restoring the SQL
  dump would erase every sale taken since the backup was made, which is a far
  worse outcome than three idle tables.

  Only if you must undo the schema, and only with the shop closed:
      php artisan migrate:rollback --step=4

==============================================================================
THE 18 FILES THIS RELEASE TOUCHES
==============================================================================
  ADDED (11)
    app/Http/Controllers/Admin/RiderController.php
    app/Models/Rider.php
    app/Models/RiderAllocation.php
    app/Models/RiderAllocationItem.php
    app/Services/Sms/RiderMessage.php
    database/migrations/2026_09_18_000001_add_idempotency_key_to_sales.php
    database/migrations/2026_09_18_000002_create_riders_table.php
    database/migrations/2026_09_18_000003_create_rider_allocations_table.php
    database/migrations/2026_09_18_000004_create_rider_allocation_items_table.php
    resources/views/admin/riders/index.blade.php
    resources/views/admin/riders/show.blade.php

  UPDATED (7)
    app/Http/Controllers/Pos/PosController.php      quick sale + idempotency
    app/Models/Sale.php                             idempotency_key fillable
    app/Models/SmsLog.php                           two new rider purposes
    app/Services/ReferenceNumberService.php         RDR reference generator
    resources/views/components/sidebar-layout.blade.php   Rider Cylinders nav
    resources/views/pos/dashboard.blade.php         cart removed, Pick-up added
    routes/web.php                                  rider routes

  Plus public_html/build/* (rebuilt CSS and JS) and public_html/sw.js (cache
  name bumped to v4-20260918).
