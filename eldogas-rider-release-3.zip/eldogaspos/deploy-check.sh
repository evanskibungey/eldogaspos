#!/bin/bash
# =============================================================================
# deploy-check.sh - is it safe to extract this release over production?
#
# Reads source files only. Changes nothing. Safe to run as often as you like.
#
# Run from the Laravel app root (the folder containing `artisan`), with
# baseline-manifest.txt and release-manifest.txt beside it:
#
#     bash deploy-check.sh
#
# Exit codes:  0 = safe   1 = STOP, server-side edits found   2 = check invalid
#
# WHY THREE-WAY
# This server has been edited directly in the past, and a deploy once nearly
# overwrote work that existed only here. Comparing the server against the new
# release alone cannot tell "we changed this file" from "someone changed it on
# the server". So every file is compared against TWO fingerprints:
#
#   baseline-manifest.txt  what the previous release (Aug 2026) shipped
#   release-manifest.txt   what this release ships
#
# If a file on the server still matches the baseline, nobody touched it since
# the last deploy and overwriting it is safe. If it matches neither, someone
# edited it here - and extracting would destroy that edit.
#
# LINE ENDINGS
# The release is built on Windows (CRLF); this server stores LF. File contents
# are normalised with tr -d '\r' before hashing, and manifest lines have any
# trailing CR stripped before they are read. Without that second step a
# Windows-saved manifest leaves "\r" on every path, nothing matches, the check
# compares zero files - and then reports SAFE. The "check invalid" guard below
# exists so that can never happen silently.
# =============================================================================

set -u

BASELINE="baseline-manifest.txt"
RELEASE="release-manifest.txt"

for f in "$BASELINE" "$RELEASE" artisan; do
    if [ ! -f "$f" ]; then
        echo "Cannot find $f. Run this from the app root with both manifests beside artisan."
        exit 2
    fi
done

SERVER=$(mktemp)
trap 'rm -f "$SERVER"' EXIT

# Seeders are excluded on purpose: they are never shipped, and the local
# DatabaseSeeder would duplicate the live catalogue if anyone ran db:seed.
find app resources routes config database/migrations \
     -type f \( -name '*.php' -o -name '*.blade.php' \) 2>/dev/null \
| sort \
| while IFS= read -r f; do
    printf '%s  %s\n' "$(tr -d '\r' < "$f" | md5sum | cut -d' ' -f1)" "$f"
done > "$SERVER"

awk -v BF="$BASELINE" -v RF="$RELEASE" '
function path(line, h) { return substr(line, length(h) + 3) }

# Before any other rule reads the line: drop a trailing CR (see header).
{ sub(/\r$/, "") }

FILENAME == BF { if ($0 !~ /database\/seeders\//) B[path($0, $1)] = $1; next }
FILENAME == RF { if ($0 !~ /database\/seeders\//) R[path($0, $1)] = $1; next }
               { S[path($0, $1)] = $1 }

END {
    for (p in R) { seen[p] = 1; nr++ }
    for (p in S) { seen[p] = 1; ns++ }

    for (p in seen) {
        inR = (p in R); inS = (p in S); inB = (p in B)

        if (inR && inS && S[p] == R[p])                   { current[++nc] = p;  continue }
        if (inR && !inS)                                  { added[++na]   = p;  continue }
        if (inR && inS && inB && S[p] == B[p])            { update[++nu]  = p;  continue }
        if (inR && inS)                                   { danger[++nd]  = p;  continue }
        if (!inR && inS)                                  { onlyhere[++no] = p; continue }
    }

    # Guard against a silent false pass. On a live install most release files
    # already exist here, so if NOT ONE path lines up between the release and
    # this server, the comparison did not really happen - wrong folder, or a
    # damaged manifest - and "no danger found" would mean nothing.
    if (nr > 0 && ns > 0 && (nc + nu + nd) == 0) {
        print ""
        print " RESULT: CHECK INVALID - not one file matched between the release"
        print " manifest and this server, so nothing was actually compared."
        printf "   release files: %d   server files: %d   matched: 0\n", nr, ns
        print " Make sure you are in the app root (the folder with artisan) and"
        print " that both manifest files came from the release zip unmodified."
        exit 2
    }

    print ""
    print "==================================================================="
    print " DANGER - edited on this server since the last deploy"
    print " Extracting the release WOULD OVERWRITE these edits."
    print "==================================================================="
    if (nd == 0) print "  (none)"
    for (i = 1; i <= nd; i++) print "  " danger[i]

    print ""
    print "-------------------------------------------------------------------"
    print " ONLY ON SERVER - not in this release (extraction leaves them alone)"
    print "-------------------------------------------------------------------"
    if (no == 0) print "  (none)"
    for (i = 1; i <= no; i++) {
        note = ""
        if (onlyhere[i] == "app/Http/Controllers/Pos/ReportController.php")
            note = "   <- DELETE: declares Admin namespace, can shadow the real controller"
        print "  " onlyhere[i] note
    }

    print ""
    print "-------------------------------------------------------------------"
    printf " SAFE  will update: %d   will add: %d   already current: %d\n", nu, na, nc
    print "-------------------------------------------------------------------"

    print ""
    if (nd > 0) {
        print " RESULT: STOP. Do not extract."
        print " Copy the DANGER files down, merge them into the local project,"
        print " rebuild the release, and run this check again."
        exit 1
    }
    print " RESULT: SAFE to extract. No server-side edits would be lost."
    exit 0
}
' "$BASELINE" "$RELEASE" "$SERVER"
