EldoGas POS - SMS + fixes release                                  2026-09-11
==============================================================================

Target:   sales.eldogas.co.ke   (cPanel)
App root: ~/domains/sales.eldogas.co.ke/eldogaspos
Web root: ~/domains/sales.eldogas.co.ke/public_html

Every command below starts with an explicit `cd`, so it works no matter which
folder the terminal was left in. Run them in order.

WILL THIS LOSE DATA?
  No. Every database change in this release only ADDS: two new tables
  (sms_logs, jobs) and five new rows in `settings`, each skipped if it already
  exists. No existing row is modified or deleted.

  The real risk on this server is CODE, not data: files have been edited here
  directly before. Step 3 checks for that and tells you to stop if it finds any.

------------------------------------------------------------------------------
WHAT IS IN THIS PACKAGE
------------------------------------------------------------------------------
  eldogaspos/app, resources, routes, config, database/migrations
  eldogaspos/deploy-check.sh          safety check (read-only)
  eldogaspos/baseline-manifest.txt    what the previous release shipped
  eldogaspos/release-manifest.txt     what this release ships
  public_html/build/                  rebuilt CSS + JS
  public_html/sw.js                   service worker, cache version bumped

DELIBERATELY NOT INCLUDED - do not add these
  .env                  the server keeps its own; you ADD keys in step 8
  vendor/               no dependency changes in this release
  database/seeders/     would duplicate the live catalogue if db:seed ran
  storage/              live runtime data
  public_html/index.php production's copy points at ../eldogaspos - the local
                        one does not, and would take the whole site down
  public_html/.htaccess cPanel may have added PHP-version handlers to it
  public_html/hot       would point the site at a dev server; all CSS/JS lost
  tests/, phpunit.xml   NEVER run tests on production - they wipe the database

==============================================================================
STEP 1 - BACK UP  (do not skip)
==============================================================================
  Database - cPanel > phpMyAdmin > select the database > Export > Quick >
  Format: SQL > Go. Save the .sql file to your own computer.

  Code - cPanel > Terminal:

    cd ~/domains/sales.eldogas.co.ke
    tar --exclude='eldogaspos/vendor' --exclude='eldogaspos/storage/logs' \
        -czf ~/backup-code-$(date +%Y%m%d-%H%M).tar.gz eldogaspos public_html
    ls -lh ~/backup-code-*.tar.gz

  (--exclude must come BEFORE the folder names, or GNU tar ignores it.)

  Confirm the .sql file and the .tar.gz both exist and are not empty.

==============================================================================
STEP 2 - UNPACK INTO A HOLDING FOLDER, NOT OVER THE LIVE SITE
==============================================================================
  Upload eldogas-sms-release.zip to ~/domains/sales.eldogas.co.ke/ then:

    cd ~/domains/sales.eldogas.co.ke
    rm -rf release-staging
    unzip -q eldogas-sms-release.zip -d release-staging

    cp release-staging/eldogaspos/deploy-check.sh \
       release-staging/eldogaspos/baseline-manifest.txt \
       release-staging/eldogaspos/release-manifest.txt \
       eldogaspos/

  Nothing live has changed yet - only the three check files were copied.

==============================================================================
STEP 3 - SAFETY CHECKS  (all read-only, nothing is changed)
==============================================================================
  3a. Server-side edits since the last deploy:

        cd ~/domains/sales.eldogas.co.ke/eldogaspos
        bash deploy-check.sh

      "RESULT: STOP"           -> do not continue. Download the files listed
                                  under DANGER and send them over so they can
                                  be merged into the release first.
                                  Extracting would destroy them.
      "RESULT: CHECK INVALID"  -> do not continue. Nothing was actually
                                  compared: you are in the wrong folder, or a
                                  manifest was damaged in transfer. cd into
                                  the folder with artisan, re-upload the zip,
                                  and run the check again.
      "RESULT: SAFE"           -> continue.

  3b. Which migrations will run:

        cd ~/domains/sales.eldogas.co.ke/eldogaspos
        php artisan migrate:status

      Expect these five as Pending:
        2026_09_09_000001_create_sms_logs_table
        2026_09_09_000002_create_jobs_table
        2026_09_09_000003_add_sms_settings
        2026_09_10_000001_add_sms_app_link_setting
        2026_09_10_000002_add_app_store_url_setting

      IF ANY 2026_08_12_* MIGRATION IS ALSO PENDING, the previous stock-control
      release was never migrated. Those four alter existing tables. Run:

        php artisan deploy:preflight

      and do not continue until it reports no blockers.

  3c. The exact SQL, without running it:

        cd ~/domains/sales.eldogas.co.ke/eldogaspos
        php artisan migrate --pretend

      Read it. For the five SMS migrations you should see only CREATE TABLE
      and INSERT INTO `settings` - no DROP, no DELETE, no TRUNCATE.

==============================================================================
STEP 4 - MAINTENANCE MODE
==============================================================================
  Stops a sale landing mid-migration. The secret lets you check the site
  yourself while customers see the maintenance page.

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan down --secret="eldogas-deploy-check"

  Your bypass link:  https://sales.eldogas.co.ke/eldogas-deploy-check

==============================================================================
STEP 5 - COPY THE RELEASE OVER THE LIVE SITE
==============================================================================
    cd ~/domains/sales.eldogas.co.ke
    cp -r release-staging/eldogaspos/.   eldogaspos/
    cp -r release-staging/public_html/.  public_html/

  Copying never deletes, so remove these by hand (each is harmless if absent):

    cd ~/domains/sales.eldogas.co.ke
    rm -f eldogaspos/app/Http/Controllers/Pos/ReportController.php
    rm -f eldogaspos/app/Http/Controllers/Pos/CylinderController.php.backup
    rm -f public_html/js/pos-system.js

  The first one matters: it declares the Admin namespace and can shadow the
  real ReportController.

==============================================================================
STEP 6 - MIGRATE
==============================================================================
    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan migrate --force

  --force is required in production. It runs only the Pending migrations.

  NEVER run any of these on production - each one destroys data:
      migrate:fresh    migrate:refresh    migrate:reset    db:wipe    db:seed

==============================================================================
STEP 7 - CLEAR CACHES AND BRING THE SITE BACK
==============================================================================
    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan config:clear
    php artisan cache:clear
    php artisan view:clear
    php artisan route:clear
    php artisan up

  Use route:clear - not route:cache or route:list. A known broken /api/users
  route (its API\UserController does not exist) makes both of those error.

==============================================================================
STEP 8 - CONFIGURE SMS
==============================================================================
  8a. Check the queue setting FIRST:

        cd ~/domains/sales.eldogas.co.ke/eldogaspos
        grep QUEUE_CONNECTION .env

      Expect:  QUEUE_CONNECTION=sync

      If it says `database` or `redis`, messages are placed on a queue that
      nothing on this server processes, so they would never send. Change it to
      sync (or arrange a `php artisan queue:work` process with your host).

  8b. Add these to eldogaspos/.env - edit the existing file, never replace it:

        SMS_DRIVER=talksasa
        TALKSASA_BASE_URL=https://bulksms.talksasa.com/api/v3
        TALKSASA_TOKEN="your-token-here"
        TALKSASA_SENDER_ID=ELDOGAS
        TALKSASA_TIMEOUT=15
        TALKSASA_PLUS_PREFIX=false

      Keep the quotes around the token - it contains a | character.

  8c. Load and test:

        cd ~/domains/sales.eldogas.co.ke/eldogaspos
        php artisan config:clear
        php artisan sms:test 07XXXXXXXX

      It asks before sending, then prints the gateway's reply.

  Forgetting this step fails safe: without SMS_DRIVER=talksasa the app only
  writes messages to its log and sends nothing.

==============================================================================
STEP 9 - SETTINGS  (System Settings page, logged in as admin)
==============================================================================
  SMS Notifications
    [ ] Enable SMS             starts OFF on purpose - tick it when ready
    Customer app link          the link printed in every message
    App store URL              where https://sales.eldogas.co.ke/app redirects

  Receipt Footer Message
    Set to:  ItishaTunaDeliver, Asante.

    IMPORTANT: this release makes printed receipts, on-screen receipts and SMS
    all read this one setting. The release does NOT change the stored value -
    if production's still says "Thank you for your business!", that is what
    receipts will now print. Set it here.

==============================================================================
STEP 10 - VERIFY, THEN TIDY UP
==============================================================================
  Log in and open each of these. Every one should load:
    Admin dashboard - charts should now DRAW (they were blank before)
    Cylinders > Pending Payments, Paid / Unpaid Drop-offs, Advance Collections
    SMS  (new sidebar item)
    POS terminal - Cash and Credit both offer Walk-in / Select / Add New

  Re-run the check. Expect "already current" for every file and nothing
  under DANGER:

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    bash deploy-check.sh

  Then remove the holding folder:

    cd ~/domains/sales.eldogas.co.ke
    rm -rf release-staging

  TILLS: the service worker cache version is bumped, so tills pick up the new
  POS screen on next load. If one does not: DevTools > Application > Service
  Workers > Unregister, then hard-refresh (Ctrl+Shift+R).

==============================================================================
IF SOMETHING GOES WRONG
==============================================================================
  Roll back the CODE, not the database:

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan down

    cd ~/domains/sales.eldogas.co.ke
    ls -lh ~/backup-code-*.tar.gz          # the one from step 1
    tar -xzf ~/backup-code-YYYYMMDD-HHMM.tar.gz

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan config:clear && php artisan view:clear && php artisan route:clear
    php artisan up

  Leave the database alone. The new tables and settings rows are simply
  ignored by the old code, so nothing breaks - and every sale taken since the
  deploy is kept.

  Restoring the SQL backup from step 1 is a LAST RESORT: it erases every sale,
  payment and customer recorded after that backup was taken.
