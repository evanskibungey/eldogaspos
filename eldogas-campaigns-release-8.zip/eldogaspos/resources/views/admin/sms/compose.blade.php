<!-- resources/views/admin/sms/compose.blade.php -->
<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Send Bulk SMS') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8 space-y-6">

            {{--
                The customer base, before any campaign is written.

                Targeting decisions are guesses without it: "customers who
                joined last month" is a different proposition at 12 people than
                at 1,200, and every one of them is billed.
            --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                    <h3 class="text-lg font-medium text-gray-900">Your customer base</h3>
                    <span class="text-sm text-gray-500">
                        {{ $audiences['all'] }} active customer{{ $audiences['all'] === 1 ? '' : 's' }}
                    </span>
                </div>

                <div class="p-6">
                    <div class="grid grid-cols-2 lg:grid-cols-5 gap-3">
                        @foreach($breakdown as $key => $row)
                            <div class="border border-gray-200 rounded-lg p-3 {{ $row['count'] === 0 ? 'opacity-60' : '' }}">
                                <p class="text-2xl font-bold text-gray-900">{{ $row['count'] }}</p>
                                <p class="text-xs font-medium text-gray-700 mt-1">{{ $row['label'] }}</p>
                                @if($row['range'])
                                    <p class="text-xs text-gray-400 mt-1">{{ $row['range'] }}</p>
                                @endif
                            </div>
                        @endforeach
                    </div>

                    @if(count($monthly) > 0)
                        <details class="mt-4">
                            <summary class="text-sm font-medium text-orange-600 cursor-pointer hover:underline">
                                Registrations month by month
                            </summary>
                            <table class="mt-3 w-full text-sm">
                                <tbody class="divide-y divide-gray-100">
                                    @foreach($monthly as $row)
                                        <tr>
                                            <td class="py-1.5 text-gray-700">{{ $row['label'] }}</td>
                                            <td class="py-1.5 text-right font-semibold text-gray-900">{{ $row['total'] }}</td>
                                            <td class="py-1.5 pl-3 w-1/2">
                                                @php
                                                    $max = max(array_column($monthly, 'total')) ?: 1;
                                                @endphp
                                                <div class="bg-orange-100 rounded h-2"
                                                     style="width: {{ max(3, round($row['total'] / $max * 100)) }}%"></div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </details>
                    @endif
                </div>
            </div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 border-b border-gray-200">

                    @if($errors->any())
                        <div class="mb-6 bg-red-50 border border-red-200 text-red-700 p-4 rounded-md">
                            <ul class="list-disc list-inside text-sm">
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    @if(config('services.talksasa.driver') === 'log')
                        <div class="mb-6 bg-yellow-50 border border-yellow-200 text-yellow-800 p-4 rounded-md text-sm">
                            <strong>Log driver active.</strong> Messages will be written to the application log,
                            not sent. Set <code>SMS_DRIVER=talksasa</code> in <code>.env</code> to send for real.
                        </div>
                    @elseif(!setting('sms_enabled', false))
                        <div class="mb-6 bg-yellow-50 border border-yellow-200 text-yellow-800 p-4 rounded-md text-sm">
                            <strong>SMS is switched off.</strong> Enable it in System Settings before sending.
                        </div>
                    @endif

                    <form method="POST" action="{{ route('admin.sms.send') }}" class="space-y-6" id="campaign-form">
                        @csrf

                        <!-- Audience -->
                        <div class="bg-gray-50 p-4 rounded-lg">
                            <h3 class="text-lg font-medium text-gray-900 mb-4">Who receives this?</h3>

                            <div class="space-y-3">
                                <label class="flex items-start p-3 bg-white border border-gray-200 rounded-md cursor-pointer hover:border-orange-400">
                                    <input type="radio" name="audience" value="all" class="mt-1 audience-option"
                                        {{ old('audience', 'all') === 'all' ? 'checked' : '' }}>
                                    <span class="ml-3">
                                        <span class="block font-medium text-gray-900">All active customers</span>
                                        <span class="block text-sm text-gray-500">{{ $audiences['all'] }} customers</span>
                                    </span>
                                </label>

                                <label class="flex items-start p-3 bg-white border border-gray-200 rounded-md cursor-pointer hover:border-orange-400">
                                    <input type="radio" name="audience" value="with_balance" class="mt-1 audience-option"
                                        {{ old('audience') === 'with_balance' ? 'checked' : '' }}>
                                    <span class="ml-3">
                                        <span class="block font-medium text-gray-900">Customers with an outstanding balance</span>
                                        <span class="block text-sm text-gray-500">{{ $audiences['with_balance'] }} customers</span>
                                    </span>
                                </label>

                                <label class="flex items-start p-3 bg-white border border-gray-200 rounded-md cursor-pointer hover:border-orange-400">
                                    <input type="radio" name="audience" value="active_cylinders" class="mt-1 audience-option"
                                        {{ old('audience') === 'active_cylinders' ? 'checked' : '' }}>
                                    <span class="ml-3">
                                        <span class="block font-medium text-gray-900">Customers with cylinders still out</span>
                                        <span class="block text-sm text-gray-500">{{ $audiences['active_cylinders'] }} customers</span>
                                    </span>
                                </label>

                                <label class="flex items-start p-3 bg-white border border-gray-200 rounded-md cursor-pointer hover:border-orange-400">
                                    <input type="radio" name="audience" value="manual" class="mt-1 audience-option"
                                        {{ old('audience') === 'manual' ? 'checked' : '' }}>
                                    <span class="ml-3">
                                        <span class="block font-medium text-gray-900">Specific numbers</span>
                                        <span class="block text-sm text-gray-500">Paste numbers, one per line</span>
                                    </span>
                                </label>
                            </div>

                            <div id="manual-numbers" class="mt-4 {{ old('audience') === 'manual' ? '' : 'hidden' }}">
                                <label for="numbers" class="block text-sm font-medium text-gray-700">Phone numbers</label>
                                <textarea name="numbers" id="numbers" rows="5"
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm font-mono"
                                    placeholder="0712345678">{{ old('numbers') }}</textarea>
                                <p class="mt-1 text-xs text-gray-500">
                                    Any format is accepted (07&hellip;, 01&hellip;, +254&hellip;). Numbers that are not valid
                                    Kenyan mobile numbers are skipped rather than sent.
                                </p>
                            </div>
                        </div>

                        {{-- Registration window. Meaningless for a pasted list, so it hides. --}}
                        <div class="bg-gray-50 p-4 rounded-lg" id="period-block">
                            <h3 class="text-lg font-medium text-gray-900 mb-1">When did they join?</h3>
                            <p class="text-sm text-gray-500 mb-4">
                                Narrows the audience above by registration date. Leave on
                                &ldquo;Any time&rdquo; to reach everyone who matches.
                            </p>

                            <select name="period" id="period"
                                class="block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm">
                                @foreach($periods as $value => $label)
                                    <option value="{{ $value }}" {{ old('period', 'any') === $value ? 'selected' : '' }}>
                                        {{ $label }}@if(isset($breakdown[$value])) &mdash; {{ $breakdown[$value]['count'] }} customers @endif
                                    </option>
                                @endforeach
                            </select>

                            <div id="custom-range" class="mt-4 grid grid-cols-2 gap-3 {{ old('period') === 'custom' ? '' : 'hidden' }}">
                                <div>
                                    <label for="date_from" class="block text-sm font-medium text-gray-700">From</label>
                                    <input type="date" name="date_from" id="date_from" value="{{ old('date_from') }}"
                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm">
                                </div>
                                <div>
                                    <label for="date_to" class="block text-sm font-medium text-gray-700">To</label>
                                    <input type="date" name="date_to" id="date_to" value="{{ old('date_to') }}"
                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm">
                                </div>
                                <p class="col-span-2 text-xs text-gray-500">
                                    Both days are included.
                                </p>
                            </div>
                        </div>

                        <!-- Message -->
                        <div class="bg-gray-50 p-4 rounded-lg">
                            <div class="flex items-center justify-between mb-4">
                                <h3 class="text-lg font-medium text-gray-900">Message</h3>

                                <div class="flex flex-wrap gap-2 justify-end">
                                    <button type="button" class="template-btn px-2.5 py-1 text-xs font-medium text-orange-700 bg-orange-100 rounded hover:bg-orange-200"
                                        data-template="Order gas on the EldoGas app and get FREE delivery to your door. Download: {link}">
                                        App promo
                                    </button>
                                    <button type="button" class="template-btn px-2.5 py-1 text-xs font-medium text-orange-700 bg-orange-100 rounded hover:bg-orange-200"
                                        data-template="Need a refill? Order on the EldoGas app for FREE same-day delivery. {link}">
                                        Refill reminder
                                    </button>
                                    <button type="button" id="insert-link" class="px-2.5 py-1 text-xs font-medium text-gray-700 bg-gray-200 rounded hover:bg-gray-300">
                                        Insert app link
                                    </button>
                                </div>
                            </div>

                            <textarea name="message" id="message" rows="5" required
                                class="block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm"
                                placeholder="Type your message">{{ old('message') }}</textarea>

                            @if($appLink === '')
                                <p class="mt-2 text-xs text-yellow-700 bg-yellow-50 border border-yellow-200 rounded p-2">
                                    No app link is set. Add one under <strong>Settings &rarr; SMS app link</strong>
                                    and the buttons above will insert it.
                                </p>
                            @elseif(strlen($appLink) > 40)
                                <p class="mt-2 text-xs text-yellow-700 bg-yellow-50 border border-yellow-200 rounded p-2">
                                    The app link is <strong>{{ strlen($appLink) }} characters</strong>, which eats most of a
                                    160-character message. A short link (for example eldogas.ke/get) leaves far more room
                                    for the offer &mdash; change it under Settings.
                                </p>
                            @endif

                            <div class="mt-2 flex items-center justify-between text-sm">
                                <span class="text-gray-500">
                                    Sender ID: <span class="font-mono font-medium">{{ $senderId }}</span>
                                </span>
                                <span class="text-gray-600">
                                    <span id="char-count">0</span> chars &middot;
                                    <span id="segment-count">1</span> segment(s) per recipient
                                </span>
                            </div>
                        </div>

                        {{--
                            The estimate comes from the server, using the very
                            rules send() will use, so the number approved here is
                            the number billed. Counting in the browser would drift
                            the moment dedupe or validity rules changed.
                        --}}
                        <div class="border-2 border-orange-200 bg-orange-50 rounded-lg p-4" id="estimate-box">
                            <div class="flex items-start justify-between gap-4">
                                <div>
                                    <p class="text-sm font-medium text-gray-700">This campaign will send</p>
                                    <p class="text-3xl font-bold text-gray-900 mt-1">
                                        <span id="total-messages">0</span>
                                        <span class="text-base font-medium text-gray-600">billable messages</span>
                                    </p>
                                    <p class="text-sm text-gray-600 mt-1">
                                        <span id="recipient-count">0</span> recipients &times;
                                        <span id="segment-count-2">1</span> segment(s)
                                    </p>
                                </div>
                                <div class="text-right text-xs text-gray-600 space-y-1">
                                    <p id="range-label" class="font-medium text-gray-700"></p>
                                    <p id="skipped-label" class="text-yellow-700"></p>
                                    <p id="optout-label" class="text-gray-500"></p>
                                    <p id="preview-state" class="italic text-gray-400"></p>
                                </div>
                            </div>

                            {{--
                                What actually goes out. The opt-out line is added
                                for you, and it is billed like any other text, so
                                it is shown rather than left as a surprise.
                            --}}
                            <div class="mt-3 pt-3 border-t border-orange-200">
                                <p class="text-xs font-medium text-gray-700 mb-1">
                                    Sent as <span class="font-normal text-gray-500">(<span id="final-length">0</span> chars)</span>
                                </p>
                                <pre id="final-message" class="text-xs text-gray-800 whitespace-pre-wrap font-sans bg-white border border-orange-100 rounded p-2 min-h-[2.5rem]"></pre>
                            </div>
                        </div>

                        <!-- Confirm -->
                        <div class="flex items-start">
                            <input type="checkbox" name="confirm" id="confirm" value="1" class="mt-1">
                            <label for="confirm" class="ml-2 text-sm text-gray-700">
                                I have checked the audience and the message. Sending cannot be undone.
                            </label>
                        </div>

                        <div class="flex items-center justify-end gap-3">
                            <a href="{{ route('admin.sms.index') }}"
                                class="px-4 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50">
                                Cancel
                            </a>
                            <button type="submit"
                                class="px-4 py-2 text-sm font-medium text-white bg-orange-600 rounded-md hover:bg-orange-700">
                                Queue campaign
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    {{--
        Inlined rather than pushed to a 'scripts' stack: layouts/app.blade.php
        does not render @stack('scripts'), so anything pushed there is silently
        dropped.
    --}}
    <script>
        (function () {
            const PREVIEW_URL = @json(route('admin.sms.audience-preview'));
            const APP_LINK = @json($appLink);

            const message = document.getElementById('message');
            const numbers = document.getElementById('numbers');
            const manualBlock = document.getElementById('manual-numbers');
            const periodBlock = document.getElementById('period-block');
            const period = document.getElementById('period');
            const customRange = document.getElementById('custom-range');
            const dateFrom = document.getElementById('date_from');
            const dateTo = document.getElementById('date_to');
            const state = document.getElementById('preview-state');

            // Mirrors SmsService::segments(). A single SMS holds 160 GSM-7
            // characters (70 for unicode); once split, each part carries a
            // concatenation header and holds only 153 (67).
            function segmentsFor(text) {
                if (text.length === 0) return 1;

                const isGsm = /^[\x20-\x7E\n\r]*$/.test(text);
                const single = isGsm ? 160 : 70;
                const concatenated = isGsm ? 153 : 67;

                if (text.length <= single) return 1;
                return Math.ceil(text.length / concatenated);
            }

            function selectedAudience() {
                const chosen = document.querySelector('.audience-option:checked');
                return chosen ? chosen.value : 'all';
            }

            function setText(id, value) {
                document.getElementById(id).textContent = value;
            }

            // Character and segment counts are local - they depend only on the
            // text, so there is no reason to wait for the network.
            function refreshLocal() {
                const segments = segmentsFor(message.value);
                setText('char-count', message.value.length);
                setText('segment-count', segments);
                setText('segment-count-2', segments);
                return segments;
            }

            function refreshManual() {
                const segments = refreshLocal();
                const recipients = numbers.value.split(/[\s,;]+/).filter(Boolean).length;

                setText('recipient-count', recipients);
                setText('total-messages', recipients * segments);
                setText('range-label', '');
                setText('skipped-label', '');
                setText('optout-label', '');
                setText('final-message', '');
                setText('final-length', 0);
                state.textContent = 'Counted from the pasted list; invalid numbers are dropped when sending.';
            }

            let pending = null;

            function refreshFromServer() {
                const params = new URLSearchParams({
                    audience: selectedAudience(),
                    period: period.value,
                    message: message.value
                });

                if (period.value === 'custom') {
                    if (!dateFrom.value || !dateTo.value) {
                        state.textContent = 'Choose both dates to see the audience.';
                        setText('recipient-count', 0);
                        setText('total-messages', 0);
                        return;
                    }
                    params.set('date_from', dateFrom.value);
                    params.set('date_to', dateTo.value);
                }

                state.textContent = 'Checking…';

                fetch(PREVIEW_URL + '?' + params.toString(), {
                    headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
                })
                    .then(r => r.ok ? r.json() : Promise.reject(r))
                    .then(data => {
                        setText('recipient-count', data.recipients);
                        setText('total-messages', data.messages);
                        setText('segment-count-2', data.segments);
                        setText('range-label', data.range || data.period_label || '');
                        setText(
                            'skipped-label',
                            data.skipped > 0
                                ? data.skipped + ' skipped (no usable number, or a duplicate)'
                                : ''
                        );
                        setText(
                            'optout-label',
                            data.opted_out > 0
                                ? data.opted_out + ' excluded (opted out of marketing)'
                                : ''
                        );
                        setText('final-message', data.final_message || '');
                        setText('final-length', data.final_length || 0);
                        state.textContent = '';
                    })
                    .catch(() => {
                        state.textContent = 'Could not check the audience. The count above may be stale.';
                    });
            }

            function refresh() {
                const isManual = selectedAudience() === 'manual';

                manualBlock.classList.toggle('hidden', !isManual);
                periodBlock.classList.toggle('hidden', isManual);
                customRange.classList.toggle('hidden', period.value !== 'custom');

                refreshLocal();

                if (isManual) {
                    refreshManual();
                    return;
                }

                // Debounced: typing a message should not fire a request per
                // keystroke, and the audience only changes when a filter does.
                clearTimeout(pending);
                pending = setTimeout(refreshFromServer, 350);
            }

            document.querySelectorAll('.audience-option').forEach(o => o.addEventListener('change', refresh));
            [period, dateFrom, dateTo].forEach(el => el.addEventListener('change', refresh));
            message.addEventListener('input', refresh);
            numbers.addEventListener('input', refresh);

            document.querySelectorAll('.template-btn').forEach(function (button) {
                button.addEventListener('click', function () {
                    message.value = this.dataset.template.replace('{link}', APP_LINK).trim();
                    refresh();
                    message.focus();
                });
            });

            document.getElementById('insert-link').addEventListener('click', function () {
                if (!APP_LINK) return;
                message.value = (message.value.trim() + ' ' + APP_LINK).trim();
                refresh();
                message.focus();
            });

            refresh();
        })();
    </script>
</x-app-layout>
