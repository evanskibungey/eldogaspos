EldoGas - targeted SMS campaigns and marketing opt-out (release 8)
                                                                   2026-09-21
==============================================================================

Target:   sales.eldogas.co.ke   (cPanel)
App root: ~/domains/sales.eldogas.co.ke/eldogaspos
Web root: ~/domains/sales.eldogas.co.ke/public_html

Applies on top of RELEASE 7, which is what is live.

------------------------------------------------------------------------------
WHAT THIS ADDS - 1. TARGETING BY WHEN CUSTOMERS JOINED
------------------------------------------------------------------------------
  The SMS compose screen (Admin -> SMS -> Compose) now opens with a panel
  describing the customer base: how many customers joined this month, last
  month, in the last 3 months, in the last 4 months, and in total, each with
  the actual dates. Underneath is a month-by-month registration chart.

  A new "When did they join?" filter narrows whichever audience is selected,
  so "customers with an outstanding balance, who joined last month" is one
  selection rather than a new hardcoded option. A custom date range is
  included; both end days are inside the range.

  "This month" and "last month" are CALENDAR months - an admin asking for last
  month means the month on the wall, not the last 30 days. The 3- and 4-month
  options are rolling windows back from today.

  THE ESTIMATE NOW COMES FROM THE SERVER. It resolves the audience with the
  exact rules the send will use, so the number approved is the number billed.
  Counting in the browser would drift the moment the rules changed.

  That resolution also drops two things a raw count would include:
    - numbers the gateway cannot dial. A malformed number is still billed as
      a failed send, so it is skipped rather than attempted.
    - the same person twice. `customers.phone` is free text, so one person can
      be on file as "0712..." and "+254712...". Both would be charged and both
      would arrive. The oldest record wins.

  Two one-tap message templates are included (App promo, Refill reminder),
  plus an "Insert app link" button.

------------------------------------------------------------------------------
WHAT THIS ADDS - 2. MARKETING OPT-OUT
------------------------------------------------------------------------------
  Promotional messages are a different thing from the receipts and collection
  notices already being sent: those are asked for by making a purchase, a
  campaign is not.

  Customers gain an sms_opt_out flag, with the date they asked and whether it
  came from staff or from a text. Opting out twice keeps the FIRST date - "when
  did they ask" is the question that gets asked if a complaint is ever made.

  A RECEIPT IS NOT MARKETING. Only campaigns check the flag. Somebody who has
  opted out still gets the receipt for a cylinder they just bought, because
  that is about their own purchase. There is a test holding that line.

  Every campaign now carries an opt-out line, added centrally so it cannot be
  left off by accident, and counted in the segment estimate because it is
  billed like any other character. If the admin already wrote their own STOP
  wording it is not added twice. The wording is configurable through a
  `sms_opt_out_footer` setting; it defaults to "Reply STOP to opt out."

  With the short app link the promo still fits ONE segment:
      97 chars without the footer, 120 with it.

  Two ways to record an opt-out:

    STAFF TOGGLE on the customer page (Customers -> open one -> Marketing SMS).
    This is the path that will actually get used - people ask at the counter
    and on the phone far more often than by text.

    INBOUND STOP at POST /sms/inbound/{secret}. Accepts STOP, UNSUBSCRIBE,
    OPTOUT, CANCEL, END and QUIT, ignores anything else, and opts out EVERY
    customer record sharing that number.

  >> THE INBOUND ENDPOINT DOES NOTHING UNTIL YOU CONFIGURE IT. See the step
     after deployment below. Until then "Reply STOP" is a promise only staff
     can keep, through the toggle.

------------------------------------------------------------------------------
DATABASE CHANGES - one migration, additive
------------------------------------------------------------------------------
    2026_09_21_000001_add_sms_opt_out_to_customers
        Adds sms_opt_out (default false), sms_opt_out_at and
        sms_opt_out_source to `customers`, plus an index on the flag because
        every campaign filters on it. No existing row is read or written -
        every customer starts subscribed, exactly as today.

  NEVER on production: migrate:fresh, migrate:refresh, migrate:reset,
  db:wipe, db:seed.

ASSETS
  Stylesheet changes: app-f895ced2.css -> app-44b575f4.css (new classes on the
  compose screen). public_html must be copied in or that screen renders
  unstyled.

  public_html/sw.js is UNCHANGED at eldogas-pos-v7-20260919. The POS dashboard
  markup did not change, so till caches do not need evicting and no cashier
  needs to reload. The previous stylesheet stays on disk - a zip extract never
  deletes - so a till still serving a cached dashboard keeps working.

DELIBERATELY NOT INCLUDED - do not add these
  .env                  the server keeps its own (you will edit it by hand, below)
  vendor/               no dependency changes
  database/seeders/     would duplicate the live catalogue if db:seed ran
  storage/              live runtime data
  public/hot            dev-server marker; shipping it breaks every asset URL
  public_html/index.php production's copy points at ../eldogaspos
  public_html/.htaccess cPanel may have added PHP-version handlers to it
  tests/, phpunit.xml   NEVER run tests on production

==============================================================================
STEP 1 - BACK UP CODE AND DATABASE
==============================================================================
    cd ~/domains/sales.eldogas.co.ke
    tar --exclude='eldogaspos/vendor' --exclude='eldogaspos/node_modules' \
        --exclude='eldogaspos/storage/logs' \
        -czf ~/backup-code-$(date +%Y%m%d-%H%M).tar.gz eldogaspos public_html
    ls -lh ~/backup-code-*.tar.gz

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    DB=$(grep -m1 '^DB_DATABASE=' .env | cut -d= -f2- | sed 's/^"//; s/"$//')
    DU=$(grep -m1 '^DB_USERNAME=' .env | cut -d= -f2- | sed 's/^"//; s/"$//')
    export MYSQL_PWD=$(grep -m1 '^DB_PASSWORD=' .env | cut -d= -f2- | sed 's/^"//; s/"$//')
    mysqldump -u "$DU" "$DB" > ~/backup-db-$(date +%Y%m%d-%H%M).sql
    unset MYSQL_PWD
    ls -lh ~/backup-db-*.sql

==============================================================================
STEP 2 - UNPACK INTO A HOLDING FOLDER
==============================================================================
  Upload eldogas-campaigns-release-8.zip to ~/domains/sales.eldogas.co.ke/ then:

    cd ~/domains/sales.eldogas.co.ke
    unzip -t eldogas-campaigns-release-8.zip | tail -2

    rm -rf release-staging
    unzip -q eldogas-campaigns-release-8.zip -d release-staging

    cp release-staging/eldogaspos/deploy-check.sh \
       release-staging/eldogaspos/baseline-manifest.txt \
       release-staging/eldogaspos/release-manifest.txt \
       eldogaspos/

==============================================================================
STEP 3 - THE CHECK  (read-only, changes nothing)
==============================================================================
    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    bash deploy-check.sh

  EXPECT EXACTLY:
      SAFE  will update: 7   will add: 2   already current: 231

  "RESULT: STOP"           -> someone edited files on the server since release
                              7. Send those files over to be merged first.
  "RESULT: CHECK INVALID"  -> wrong folder, or a manifest was damaged.
  "will add" is not 2      -> you are not on release 7. Stop and ask.
  "RESULT: SAFE"           -> continue.

==============================================================================
STEP 4 - COPY IT IN AND MIGRATE
==============================================================================
  One additive migration, admin screens and config. Nothing the tills use
  changes. Safe to do live.

    cd ~/domains/sales.eldogas.co.ke
    cp -r release-staging/eldogaspos/.   eldogaspos/
    cp -r release-staging/public_html/.  public_html/

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan migrate --force

  Expect one line ending DONE:
      2026_09_21_000001_add_sms_opt_out_to_customers ..... DONE

    php artisan config:clear && php artisan cache:clear
    php artisan view:clear   && php artisan route:clear

  config:clear and route:clear both matter: config/services.php gained a key
  and there is a new public route.

==============================================================================
STEP 5 - SET THE APP LINK (one minute, saves half your campaign budget)
==============================================================================
  Admin -> Settings -> "Customer app link (sent in SMS)":

      https://eldogas.ke/get

  The long Play Store URL is 90 characters and pushes a normal promo to 165 -
  TWO billed segments instead of one. Same message, half the cost, on every
  campaign AND every receipt that carries the link.

  Leave the separate "app_store_url" setting alone - it is what eldogas.ke/get
  redirects TO, and changing it breaks every SMS already sent.

==============================================================================
STEP 6 - VERIFY
==============================================================================
  a. Admin -> SMS -> Compose. The page opens with "Your customer base" and
     five counts. Check they look right against what you know of the shop.

  b. Choose "Joined last month". The estimate underneath should change, and
     show the date range it covers.

  c. Press the "App promo" template button. Confirm the message ends with the
     app link and that "Sent as" underneath shows the opt-out line added, at
     ONE segment.

  d. DO NOT PRESS SEND YET. Open a customer (Customers -> pick one) and use
     Marketing SMS -> Opt out. Go back to Compose and confirm the recipient
     count dropped by one and it says "1 excluded (opted out of marketing)".

  e. Put that customer back with Marketing SMS -> Resume.

  f. Send a real campaign to yourself first: audience "Specific numbers",
     paste your own number, send. Check the text arrives with the opt-out line.

  g. Re-run the check:

       cd ~/domains/sales.eldogas.co.ke/eldogaspos
       bash deploy-check.sh

     Expect: will update: 0   will add: 0   already current: 240

  h. Tidy up:

       cd ~/domains/sales.eldogas.co.ke && rm -rf release-staging

==============================================================================
STEP 7 - MAKE "REPLY STOP" REAL  (do this, or change the wording)
==============================================================================
  The inbound endpoint ships closed. With no secret configured it returns 404,
  which is the safe default: no secret, no open endpoint.

  1. Add a secret to production .env (any long random string):

       cd ~/domains/sales.eldogas.co.ke/eldogaspos
       nano .env
       # add:  TALKSASA_INBOUND_SECRET=<long random string>

       php artisan config:clear

  2. In the TalkSasa dashboard, set the inbound / callback URL to:

       https://sales.eldogas.co.ke/sms/inbound/<that same secret>

  3. Test it by texting STOP to your sender ID from a phone that is on file as
     a customer, then check that customer's page shows "Opted out - replied
     STOP".

  IF TALKSASA DOES NOT SUPPORT INBOUND SMS ON YOUR PLAN, do not leave the
  footer promising something that cannot happen. Change it under
  Settings, or ask for the wording to be swapped for something you can honour,
  for example "To stop these messages call 07xx xxx xxx".

  Until either is done, staff must honour STOP requests using the toggle on
  the customer page.

==============================================================================
IF SOMETHING GOES WRONG
==============================================================================
  ROLL BACK THE CODE, NOT THE DATABASE.

    cd ~/domains/sales.eldogas.co.ke
    ls -lh ~/backup-code-*.tar.gz          # the one from step 1
    tar -xzf ~/backup-code-YYYYMMDD-HHMM.tar.gz

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan config:clear && php artisan view:clear && php artisan route:clear

  Leave the migration in place. The restored release-7 code never reads the
  opt-out columns and they are nullable or defaulted, so customers carry on
  working. Restoring a database dump would erase every sale taken since the
  backup.

  NOTE: rolling back means opt-outs stop being honoured, because release 7 has
  no concept of them. If you have already told customers they can opt out, do
  not leave a rollback in place any longer than it takes to fix the problem.

==============================================================================
THE 9 FILES THIS RELEASE TOUCHES
==============================================================================
  ADDED (2)
    app/Services/Sms/CampaignAudience.php            targeting, dedupe, footer
    database/migrations/2026_09_21_000001_add_sms_opt_out_to_customers.php

  UPDATED (7)
    app/Http/Controllers/Admin/SmsController.php     preview, opt-out, inbound
    app/Models/Customer.php                          marketable(), opt in/out
    app/Http/Middleware/VerifyCsrfToken.php          exempts the inbound URL
    config/services.php                              talksasa.inbound_secret
    routes/web.php                                   preview, opt-out, inbound
    resources/views/admin/sms/compose.blade.php      base panel, filter, estimate
    resources/views/admin/customers/show.blade.php   the Marketing SMS toggle

  Plus public_html/build/* (new stylesheet app-44b575f4.css). sw.js unchanged.
