COMPLETE SOURCE PACKAGE - eldogas stock-control update
======================================================
Extract into:  ~/domains/sales.eldogas.co.ke/

  eldogaspos/     -> app, resources, routes, config, database/migrations
  public_html/    -> sw.js (updated) and build/ assets

DELIBERATELY NOT INCLUDED
  .env                  server keeps its own
  vendor/               no dependency changes
  database/seeders/     production keeps its own. Local's DatabaseSeeder also
                        runs CategorySeeder + ProductSeeder, which would
                        duplicate your live catalogue if anyone ran db:seed.
  storage/              runtime data

AFTER EXTRACTING
  cd ~/domains/sales.eldogas.co.ke/eldogaspos
  php artisan config:clear && php artisan cache:clear
  php artisan view:clear   && php artisan route:clear

  Then verify with:  bash compare.sh    (expect zero drift on app/resources/routes)

SERVICE WORKER
  sw.js CACHE_NAME is bumped and POS pages are now network-first. Staff whose
  browsers cached the old dashboard will pick up the new one on next load.
  If a till is stubborn: DevTools > Application > Service Workers > Unregister,
  then hard-refresh.
