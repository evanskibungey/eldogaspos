#!/bin/bash
# Compares this server's source files against a manifest taken from the
# development machine, and reports exactly where the two have drifted.
#
# Usage, from the Laravel app root, with local-manifest.txt beside it:
#   bash compare.sh
#
# Reads nothing but source files. Changes nothing.

set -u

APP_ROOT="$(pwd)"
LOCAL_MANIFEST="${1:-local-manifest.txt}"

if [ ! -f "$LOCAL_MANIFEST" ]; then
    echo "Cannot find $LOCAL_MANIFEST - upload it next to artisan first."
    exit 1
fi

echo "Comparing $APP_ROOT against $LOCAL_MANIFEST"
echo "==============================================================="

TMP_PROD=$(mktemp)
TMP_L=$(mktemp)
TMP_P=$(mktemp)

# Fingerprint this server, normalising line endings the same way.
find app resources routes config database/migrations database/seeders \
     -type f \( -name '*.php' -o -name '*.blade.php' \) 2>/dev/null \
| sort \
| while IFS= read -r f; do
    printf '%s  %s\n' "$(tr -d '\r' < "$f" | md5sum | cut -d' ' -f1)" "$f"
done > "$TMP_PROD"

# key = path, value = hash
awk '{h=$1; $1=""; sub(/^  /,""); print $0 "\t" h}' "$LOCAL_MANIFEST" | sort > "$TMP_L"
awk '{h=$1; $1=""; sub(/^  /,""); print $0 "\t" h}' "$TMP_PROD"       | sort > "$TMP_P"

echo
echo "--- DIFFERENT (exists both sides, contents differ) ---"
join -t $'\t' -j 1 -o 0,1.2,2.2 "$TMP_L" "$TMP_P" \
    | awk -F'\t' '$2 != $3 { print "  " $1 }' | tee /tmp/_diff.txt
DIFF_N=$(wc -l < /tmp/_diff.txt)
[ "$DIFF_N" -eq 0 ] && echo "  (none)"

echo
echo "--- MISSING ON SERVER (present locally, absent here) ---"
join -t $'\t' -v 1 -j 1 "$TMP_L" "$TMP_P" | cut -f1 | sed 's/^/  /' | tee /tmp/_miss.txt
MISS_N=$(wc -l < /tmp/_miss.txt)
[ "$MISS_N" -eq 0 ] && echo "  (none)"

echo
echo "--- ONLY ON SERVER (present here, absent locally) ---"
echo "    these are the dangerous ones - work that exists only in production"
join -t $'\t' -v 2 -j 1 "$TMP_L" "$TMP_P" | cut -f1 | sed 's/^/  /' | tee /tmp/_extra.txt
EXTRA_N=$(wc -l < /tmp/_extra.txt)
[ "$EXTRA_N" -eq 0 ] && echo "  (none)"

echo
echo "==============================================================="
printf "different: %s   missing on server: %s   only on server: %s\n" \
       "$DIFF_N" "$MISS_N" "$EXTRA_N"
echo
echo "Server file count: $(wc -l < "$TMP_PROD")"
echo "Local file count:  $(wc -l < "$LOCAL_MANIFEST")"

rm -f "$TMP_PROD" "$TMP_L" "$TMP_P"
