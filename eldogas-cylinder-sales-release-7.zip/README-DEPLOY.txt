EldoGas - cylinder refills count as sales (release 7)              2026-09-20
==============================================================================

Target:   sales.eldogas.co.ke   (cPanel)
App root: ~/domains/sales.eldogas.co.ke/eldogaspos
Web root: ~/domains/sales.eldogas.co.ke/public_html

Applies on top of RELEASE 6, which is what is live.

------------------------------------------------------------------------------
THE PROBLEM THIS FIXES
------------------------------------------------------------------------------
  Completing a cylinder transaction took money and moved stock, but wrote NO
  row in `sales`. The POS sales badge, the admin Sales Overview and every
  cashier report all count `sales` - so the entire refill side of the business
  was invisible to them.

  On the live data as of today that is:

      sales rows                      19   KSh 56,560
      completed cylinder transactions 18   KSh 51,380   <- counted nowhere

  About half the shop's takings. The money was collected and the stock was
  deducted; the two halves of the business were simply counted in two places
  that never met.

------------------------------------------------------------------------------
WHAT THIS CHANGES
------------------------------------------------------------------------------
  Completing a cylinder transaction now records a sale, so refills appear in
  the POS sales badge, the Sales Overview and the cashier reports alongside
  till sales.

  STOCK IS NOT DEDUCTED TWICE. This is the part that matters. By the time the
  sale is written the cylinders have already left, under the stock movement
  `cylinder_collection`. The sale is recorded ALONGSIDE that movement and
  deliberately does NOT go through StockService - doing so would deduct the
  same cylinders a second time. A test asserts stock moves exactly once:
  30 -> 27 for a 3-cylinder collection, one movement row, zero `sale`
  movements.

  Guards:
    - `sale_id` on the transaction makes it idempotent. Completing twice - a
      double submit, a retried request - books the money once.
    - Cancelling records no sale at all, and releases the stock as before.
    - An unpaid collection records an UNPAID sale, not phantom revenue.
    - The refundable deposit is excluded from the sale total. A deposit is an
      obligation handed back at completion, not money earned.

  New class app/Services/FulfilmentSaleRecorder.php: "record revenue for work
  fulfilled away from the till" is now one thing instead of logic copied per
  feature.

  ADVANCE COLLECTIONS - worth knowing
  Both types record their sale at completion, which matches how the module
  reads. An advance collection takes payment at CREATION though, so its
  revenue will be dated to when the empty cylinder comes back rather than when
  the money arrived. This is currently theoretical: there are ZERO advance
  collections on the live database - all 19 transactions are drop-offs. If you
  start using them, say so and the sale can be moved to creation instead.

------------------------------------------------------------------------------
DATABASE CHANGES - one migration, additive
------------------------------------------------------------------------------
    2026_09_20_000001_add_sale_id_to_cylinder_transactions
        Adds one nullable foreign key to `cylinder_transactions`. No existing
        row is read or written; every transaction taken so far simply gets
        NULL. The table is small, so the ALTER is instant.

  NEVER on production: migrate:fresh, migrate:refresh, migrate:reset,
  db:wipe, db:seed.

------------------------------------------------------------------------------
THE BACKFILL - SHIPPED BUT NOT RUN. YOUR DECISION.
------------------------------------------------------------------------------
  This release does NOT touch the 18 transactions already completed. They stay
  uncounted until you choose otherwise, because writing them rewrites what
  past months report the shop earned - a decision for whoever owns the books,
  not something a deploy should do silently.

  A command is included. Look first; it changes nothing:

      cd ~/domains/sales.eldogas.co.ke/eldogaspos
      php artisan cylinders:backfill-sales --dry-run

  It prints every transaction it would write, with dates and amounts, then
  exits. On today's data that is 18 transactions, 18 cylinders, KSh 51,380,
  spanning 2026-08-12 to 2026-09-19.

  To actually write them (it asks for confirmation first):

      php artisan cylinders:backfill-sales

  - Each sale is dated the day the cylinders were COLLECTED, not today, so the
    revenue lands on the day it was taken.
  - PAST DAILY TOTALS WILL CHANGE. 2026-09-10 alone gains KSh 21,300.
  - Stock is never touched - it is revenue only.
  - Safe to run twice: a transaction already pointing at a sale is skipped.

  If anyone has already reported off those figures, decide before running it.

NO ASSET CHANGES
  The stylesheet and JavaScript rebuilt byte-identical to release 6
  (app-f895ced2.css, app-7efb301e.js) - no template changed. public_html is
  shipped anyway so the folder stays consistent.

  public_html/sw.js is UNCHANGED at eldogas-pos-v7-20260919. Nothing on screen
  changed, so the till caches do not need evicting and no cashier needs to
  reload. This is a backend-only release.

DELIBERATELY NOT INCLUDED - do not add these
  .env                  the server keeps its own
  vendor/               no dependency changes
  database/seeders/     would duplicate the live catalogue if db:seed ran
  storage/              live runtime data
  public/hot            dev-server marker; shipping it breaks every asset URL
  public_html/index.php production's copy points at ../eldogaspos
  public_html/.htaccess cPanel may have added PHP-version handlers to it
  tests/, phpunit.xml   NEVER run tests on production

==============================================================================
STEP 1 - BACK UP CODE AND DATABASE
==============================================================================
    cd ~/domains/sales.eldogas.co.ke
    tar --exclude='eldogaspos/vendor' --exclude='eldogaspos/node_modules' \
        --exclude='eldogaspos/storage/logs' \
        -czf ~/backup-code-$(date +%Y%m%d-%H%M).tar.gz eldogaspos public_html
    ls -lh ~/backup-code-*.tar.gz

  Take the database backup too. The migration itself cannot lose data, but if
  you go on to run the backfill you will be writing 18 new sales rows, and a
  restore point before that is worth having.

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    DB=$(grep -m1 '^DB_DATABASE=' .env | cut -d= -f2- | sed 's/^"//; s/"$//')
    DU=$(grep -m1 '^DB_USERNAME=' .env | cut -d= -f2- | sed 's/^"//; s/"$//')
    export MYSQL_PWD=$(grep -m1 '^DB_PASSWORD=' .env | cut -d= -f2- | sed 's/^"//; s/"$//')
    mysqldump -u "$DU" "$DB" > ~/backup-db-$(date +%Y%m%d-%H%M).sql
    unset MYSQL_PWD
    ls -lh ~/backup-db-*.sql

==============================================================================
STEP 2 - UNPACK INTO A HOLDING FOLDER
==============================================================================
  Upload eldogas-cylinder-sales-release-7.zip to
  ~/domains/sales.eldogas.co.ke/ then:

    cd ~/domains/sales.eldogas.co.ke
    unzip -t eldogas-cylinder-sales-release-7.zip | tail -2

    rm -rf release-staging
    unzip -q eldogas-cylinder-sales-release-7.zip -d release-staging

    cp release-staging/eldogaspos/deploy-check.sh \
       release-staging/eldogaspos/baseline-manifest.txt \
       release-staging/eldogaspos/release-manifest.txt \
       eldogaspos/

==============================================================================
STEP 3 - THE CHECK  (read-only, changes nothing)
==============================================================================
    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    bash deploy-check.sh

  EXPECT EXACTLY:
      SAFE  will update: 2   will add: 3   already current: 233

  "RESULT: STOP"           -> someone edited files on the server since release
                              6. Send those files over to be merged first.
  "RESULT: CHECK INVALID"  -> wrong folder, or a manifest was damaged.
  "will update" is larger  -> you are not on release 6. Stop and ask.
  "RESULT: SAFE"           -> continue.

==============================================================================
STEP 4 - COPY IT IN AND MIGRATE
==============================================================================
  One additive column, two models, one controller. Nothing on screen changes.
  Safe to do live; maintenance mode is optional.

    cd ~/domains/sales.eldogas.co.ke
    cp -r release-staging/eldogaspos/.   eldogaspos/
    cp -r release-staging/public_html/.  public_html/

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan migrate --force

  Expect one line ending DONE:
      2026_09_20_000001_add_sale_id_to_cylinder_transactions ..... DONE

    php artisan config:clear && php artisan cache:clear
    php artisan view:clear   && php artisan route:clear

==============================================================================
STEP 5 - VERIFY
==============================================================================
  a. Note the number on the POS header "Sales" badge.

  b. Take a cylinder drop-off through to completion:
     Cylinder Management -> New Transaction -> complete it.

  c. Reload /pos/dashboard. The Sales badge must have gone UP BY ONE, and
     Sales History must show the refill with the right amount.

  d. THE IMPORTANT CHECK - stock moved only once. Note the product's stock
     before completing another transaction, complete it, and confirm the stock
     fell by exactly the number of cylinders on that transaction. Not double.

     Inventory -> the product -> Stock Movements should show ONE movement for
     that collection, typed `cylinder_collection`.

  e. Admin -> Dashboard -> Sales Overview "Today's Sales" should now agree
     with the POS badge, and both should include the refill.

  f. Re-run the check:

       cd ~/domains/sales.eldogas.co.ke/eldogaspos
       bash deploy-check.sh

     Expect: will update: 0   will add: 0   already current: 238

  g. Tidy up:

       cd ~/domains/sales.eldogas.co.ke && rm -rf release-staging

  h. THEN, separately and only when you have decided about history, run the
     dry run described above and choose whether to backfill.

==============================================================================
IF SOMETHING GOES WRONG
==============================================================================
  ROLL BACK THE CODE, NOT THE DATABASE.

    cd ~/domains/sales.eldogas.co.ke
    ls -lh ~/backup-code-*.tar.gz          # the one from step 1
    tar -xzf ~/backup-code-YYYYMMDD-HHMM.tar.gz

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan config:clear && php artisan view:clear && php artisan route:clear

  Leave the migration in place. The restored release-6 code never reads
  cylinder_transactions.sale_id and the column is nullable, so cylinder
  transactions carry on working. Restoring a database dump would erase every
  sale taken since the backup, which is far worse than one idle column.

  IF YOU RAN THE BACKFILL AND WANT IT UNDONE, that is a database change, not a
  code one. The sales it wrote all carry "- backfilled" in their notes:

      SELECT id, receipt_number, created_at, total_amount FROM sales
      WHERE notes LIKE '%backfilled%';

  Check that list before deleting anything, and clear the matching
  cylinder_transactions.sale_id values in the same breath.

==============================================================================
THE 5 FILES THIS RELEASE TOUCHES
==============================================================================
  ADDED (3)
    app/Services/FulfilmentSaleRecorder.php          writes the sale, no stock
    app/Console/Commands/BackfillCylinderSales.php   the opt-in backfill
    database/migrations/2026_09_20_000001_add_sale_id_to_cylinder_transactions.php

  UPDATED (2)
    app/Http/Controllers/Admin/CylinderController.php  records the sale on
                                                       completion
    app/Models/CylinderTransaction.php                 sale_id, sale(),
                                                       saleLines(),
                                                       saleAlreadyRecorded()

  public_html/* is shipped unchanged (same stylesheet, same sw.js).
