# Images Directory

This directory contains images for the application.

## Required Files:
- `placeholder.jpg` - A placeholder image for products without images (recommended size: 300x300px)

You can add a placeholder.jpg image here or update the code to use a different placeholder image path.