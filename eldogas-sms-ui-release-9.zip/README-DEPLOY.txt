EldoGas - SMS menu, compose redesign, page headers fixed (release 9)
                                                                   2026-09-21
==============================================================================

Target:   sales.eldogas.co.ke   (cPanel)
App root: ~/domains/sales.eldogas.co.ke/eldogaspos
Web root: ~/domains/sales.eldogas.co.ke/public_html

Applies on top of RELEASE 8, which is what is live.

Three blade files. No migrations, no database changes, no new routes.

------------------------------------------------------------------------------
1. A BUG: EVERY PAGE HEADER WAS BEING THROWN AWAY
------------------------------------------------------------------------------
  Eleven views pass an <x-slot name="header">, and nothing ever rendered it -
  neither layouts/app.blade.php nor the sidebar layout output $header. Their
  titles vanished, and so did any button sitting inside them.

  That is why the SMS page showed "Eldogas" instead of "SMS History", and why
  its "Send bulk SMS" button could not be found - the page had to be reached
  by typing /admin/sms/compose.

  Fixed in layouts/app.blade.php. Affected pages: SMS history and compose,
  Categories, Users, Products create/edit, Settings, Profile.

  To be accurate about the damage: only the SMS compose button was genuinely
  unreachable. Categories links its create route from the page body and Users
  from the sidebar, so those were awkward rather than lost.

------------------------------------------------------------------------------
2. SMS IS NOW A MENU WITH TWO ENTRIES
------------------------------------------------------------------------------
  The sidebar's SMS item becomes a dropdown, matching Sales Management:

      SMS
        - Message History
        - Compose Campaign

  It opens automatically when you are already on an SMS page, so the current
  page is visible rather than hidden behind a collapsed parent.

------------------------------------------------------------------------------
3. THE COMPOSE SCREEN, REDESIGNED
------------------------------------------------------------------------------
  THE PERIOD CARDS ARE NOW THE CONTROL. Before, five cards showed the counts
  and a dropdown underneath repeated the same numbers - choosing "last month"
  and seeing 473 was two separate actions. Now you click the card. A sixth
  card covers a custom range and reveals the date inputs.

  Restructured into three numbered steps: when did they join, which customers,
  then the message - so targeting comes first and the audience narrows down.

  Audience options became cards too, with the count right-aligned and one line
  of explanation each.

  The "Registrations month by month" box is fixed. The bare black-bordered
  strip was the browser's default <details> marker; it is now a proper
  disclosure with a chevron and rounded bars.

  The cost panel is the loudest thing on the page, with the confirmation
  checkbox inside it rather than floating below. The "Sent as" preview stays
  hidden until there is a message, instead of showing an empty box.

  NEW: A COST WARNING THAT ONLY FIRES WHEN IT MATTERS. Your live audience is
  about 5,900 reachable customers. A message that spills into a second segment
  costs 11,800 messages instead of 5,900. When the audience is over 1,000 AND
  the message is multi-segment, the panel now says exactly how many messages
  trimming below 160 characters would save.

  Counts are thousand-separated throughout; "5906" reads badly at that size.

------------------------------------------------------------------------------
STILL WORTH DOING - THE APP LINK
------------------------------------------------------------------------------
  If Settings -> "Customer app link (sent in SMS)" still holds the 90-character
  Play Store URL, the compose screen will now show a yellow warning saying so.

  Set it to:   https://eldogas.ke/get

  At 5,900 recipients that one setting is the difference between roughly 5,900
  and 11,800 billable messages PER CAMPAIGN - and it shortens every receipt
  carrying the link too.

  Leave the separate "app_store_url" setting alone; it is what eldogas.ke/get
  redirects TO.

NO DATABASE CHANGES AT ALL
  No migrations, no new settings, no schema change.

ASSETS - AND WHY THE TILLS NEED A RELOAD THIS TIME
  Stylesheet changes: app-44b575f4.css -> app-9df8b393.css.

  public_html/sw.js moves from eldogas-pos-v7-20260919 to v8-20260921. The
  sidebar is rendered INSIDE the POS dashboard, so changing the SMS menu
  changes that page's markup - and the service worker precaches it. Without
  the bump a till would keep serving the old screen.

  Each till needs ONE hard refresh (Ctrl+Shift+R) after this release. Nothing
  about selling changes; it is the menu that is stale otherwise.

DELIBERATELY NOT INCLUDED - do not add these
  .env                  the server keeps its own
  vendor/               no dependency changes
  database/seeders/     would duplicate the live catalogue if db:seed ran
  storage/              live runtime data
  public/hot            dev-server marker; shipping it breaks every asset URL
  public_html/index.php production's copy points at ../eldogaspos
  public_html/.htaccess cPanel may have added PHP-version handlers to it
  tests/, phpunit.xml   NEVER run tests on production

==============================================================================
STEP 1 - BACK UP THE CODE
==============================================================================
    cd ~/domains/sales.eldogas.co.ke
    tar --exclude='eldogaspos/vendor' --exclude='eldogaspos/node_modules' \
        --exclude='eldogaspos/storage/logs' \
        -czf ~/backup-code-$(date +%Y%m%d-%H%M).tar.gz eldogaspos public_html
    ls -lh ~/backup-code-*.tar.gz

  No database export needed - nothing in this release touches it.

==============================================================================
STEP 2 - UNPACK INTO A HOLDING FOLDER
==============================================================================
  Upload eldogas-sms-ui-release-9.zip to ~/domains/sales.eldogas.co.ke/ then:

    cd ~/domains/sales.eldogas.co.ke
    unzip -t eldogas-sms-ui-release-9.zip | tail -2

    rm -rf release-staging
    unzip -q eldogas-sms-ui-release-9.zip -d release-staging

    cp release-staging/eldogaspos/deploy-check.sh \
       release-staging/eldogaspos/baseline-manifest.txt \
       release-staging/eldogaspos/release-manifest.txt \
       eldogaspos/

==============================================================================
STEP 3 - THE CHECK  (read-only, changes nothing)
==============================================================================
    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    bash deploy-check.sh

  EXPECT EXACTLY:
      SAFE  will update: 3   will add: 0   already current: 237

  "RESULT: STOP"           -> someone edited files on the server since release
                              8. Send those files over to be merged first.
  "RESULT: CHECK INVALID"  -> wrong folder, or a manifest was damaged.
  "will add" is not 0      -> you are not on release 8. Stop and ask.
  "RESULT: SAFE"           -> continue.

==============================================================================
STEP 4 - COPY IT IN
==============================================================================
  Three templates. No schema change, nothing to migrate. Safe to do live.

    cd ~/domains/sales.eldogas.co.ke
    cp -r release-staging/eldogaspos/.   eldogaspos/
    cp -r release-staging/public_html/.  public_html/

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan view:clear
    php artisan config:clear && php artisan cache:clear && php artisan route:clear

  view:clear is the one that matters - compiled blade is exactly what changed.

==============================================================================
STEP 5 - VERIFY
==============================================================================
  a. Hard-refresh any page (Ctrl+Shift+R). In the sidebar, SMS now expands to
     "Message History" and "Compose Campaign".

  b. Click Compose Campaign. You should get there WITHOUT typing a URL - that
     was the whole point.

  c. The page header reads "Compose Campaign" with a "Message history" button
     on the right. Go to Message History and confirm it now reads "SMS History"
     with a "Send bulk SMS" button, instead of "Eldogas" and no button.

  d. On Compose, click straight on the period cards - "Joined last month"
     should highlight and the estimate should update. Then click "Custom
     range" and confirm the date inputs appear.

  e. Open "Registrations month by month". It should be a clean list with bars,
     not a black-bordered strip.

  f. Press "App promo". If the yellow app-link warning appears, go and fix the
     setting (see above), then come back.

  g. With the app link short, a promo to all customers should read ONE segment
     and roughly 5,900 billable messages. If it says two segments and ~11,800,
     the link setting has not taken.

  h. Check the other repaired pages: Categories and Users should now show their
     titles and "Add New" buttons.

  i. On ONE till, hard-refresh /pos/dashboard and confirm selling still works
     (single tap sells, Print prints one sheet). Then do the rest.

  j. Re-run the check:

       cd ~/domains/sales.eldogas.co.ke/eldogaspos
       bash deploy-check.sh

     Expect: will update: 0   will add: 0   already current: 240

  k. Tidy up:

       cd ~/domains/sales.eldogas.co.ke && rm -rf release-staging

==============================================================================
IF SOMETHING GOES WRONG
==============================================================================
    cd ~/domains/sales.eldogas.co.ke
    ls -lh ~/backup-code-*.tar.gz          # the one from step 1
    tar -xzf ~/backup-code-YYYYMMDD-HHMM.tar.gz

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan view:clear && php artisan config:clear && php artisan route:clear

  The database is untouched by this release, so there is nothing to restore
  and no sale can be lost by rolling back. Tills will need one more hard
  refresh after a rollback, for the same service-worker reason.

==============================================================================
THE 3 FILES THIS RELEASE TOUCHES
==============================================================================
  UPDATED (3)
    resources/views/layouts/app.blade.php            renders the header slot
    resources/views/components/sidebar-layout.blade.php  SMS dropdown menu
    resources/views/admin/sms/compose.blade.php      the redesign

  Plus public_html/build/* (new stylesheet app-9df8b393.css) and
  public_html/sw.js (cache name bumped to v8-20260921).
