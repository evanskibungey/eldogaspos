EldoGas POS - branding: drop "POS" from the chrome (release 4)     2026-09-18
==============================================================================

Target:   sales.eldogas.co.ke   (cPanel)
App root: ~/domains/sales.eldogas.co.ke/eldogaspos
Web root: ~/domains/sales.eldogas.co.ke/public_html

Apply this ON TOP OF release 3. If release 3 is not on the server yet, deploy
that first - the check in step 3 will refuse this one otherwise.

------------------------------------------------------------------------------
WHAT THIS CHANGES - five blade files, cosmetic only
------------------------------------------------------------------------------
  Everything that read "EldoGas POS" or "Eldo_POS" in the site chrome now
  reads just the company name. Nothing else moves.

  resources/views/pos/dashboard.blade.php
      The POS top bar. Was "EldoGas POS", now "EldoGas". This is the one in
      the screenshot.

  resources/views/components/sidebar-layout.blade.php
      Two things. The small orange "POS System" subtitle under the company
      name in the dark sidebar is gone. And the page-heading fallback no
      longer says "EldoGas POS" when APP_NAME is unset.

  resources/views/layouts/app.blade.php
  resources/views/layouts/guest.blade.php
      Browser tab title: "EldoGas POS" -> "EldoGas". guest.blade.php also
      loses the "Eldo_POS" wordmark on the login screen.

  resources/views/welcome.blade.php
      Landing page tab title and its "Eldo_POS" wordmark.

  FALLBACK DEFAULTS CHANGED TOO - deliberate, read this
      Three of those spots rendered config('settings.company_name', 'Eldo')
      immediately followed by a literal "_POS", so the fallback was only ever
      half the name. With "_POS" removed, an unset company_name would have
      left a bare "Eldo" on screen. The default is now 'EldoGas' in all three.
      If Settings -> Company Name is filled in (it normally is), this changes
      nothing at all - the setting still wins.

  NAVIGATION LABELS ARE UNTOUCHED ON PURPOSE
      "POS Terminal" in the sidebar, "Quick POS" in the header and "Go to POS"
      on the landing page are menu labels pointing AT the POS screen, not
      branding. They still say POS, which is correct - they describe where the
      link goes.

NO DATABASE CHANGES AT ALL
  No migrations, no new settings, no schema change. Nothing to migrate.
  A database backup is not needed for this release.

NO COMPILED ASSET CHANGES
  The CSS and JS rebuilt to byte-identical files (app-646f2857.css,
  app-7efb301e.js) - only markup changed, and no Tailwind class was left
  unused. public_html/build is shipped anyway so the folder stays consistent.

SERVICE WORKER IS BUMPED
  public_html/sw.js moves from eldogas-pos-v4-20260918 to v5-20260918. The
  worker caches the /pos/dashboard HTML, so without this bump a till would
  keep showing the old "EldoGas POS" top bar indefinitely. Each till still
  needs one reload after deploying.

DELIBERATELY NOT INCLUDED - do not add these
  .env                  the server keeps its own
  vendor/               no dependency changes
  database/seeders/     would duplicate the live catalogue if db:seed ran
  storage/              live runtime data
  public/hot            dev-server marker; shipping it breaks every asset URL
  public_html/index.php production's copy points at ../eldogaspos
  public_html/.htaccess cPanel may have added PHP-version handlers to it
  tests/, phpunit.xml   NEVER run tests on production

==============================================================================
STEP 1 - BACK UP THE CODE
==============================================================================
    cd ~/domains/sales.eldogas.co.ke
    tar --exclude='eldogaspos/vendor' --exclude='eldogaspos/node_modules' \
        --exclude='eldogaspos/storage/logs' \
        -czf ~/backup-code-$(date +%Y%m%d-%H%M).tar.gz eldogaspos public_html
    ls -lh ~/backup-code-*.tar.gz

  No database export needed - nothing in this release touches it.

==============================================================================
STEP 2 - UNPACK INTO A HOLDING FOLDER
==============================================================================
  Upload eldogas-branding-release-4.zip to ~/domains/sales.eldogas.co.ke/ then:

    cd ~/domains/sales.eldogas.co.ke
    unzip -t eldogas-branding-release-4.zip | tail -2

    rm -rf release-staging
    unzip -q eldogas-branding-release-4.zip -d release-staging

    cp release-staging/eldogaspos/deploy-check.sh \
       release-staging/eldogaspos/baseline-manifest.txt \
       release-staging/eldogaspos/release-manifest.txt \
       eldogaspos/

==============================================================================
STEP 3 - THE CHECK  (read-only, changes nothing)
==============================================================================
    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    bash deploy-check.sh

  EXPECT EXACTLY:
      SAFE  will update: 5   will add: 0   already current: 228

  "RESULT: STOP"           -> someone edited files on the server since release
                              3. Send those files over to be merged first.
  "RESULT: CHECK INVALID"  -> wrong folder, or a manifest was damaged.
  "will add" is not 0      -> you are still on release 2. Deploy release 3
                              first, then come back to this one.
  "RESULT: SAFE"           -> continue.

==============================================================================
STEP 4 - COPY IT IN
==============================================================================
  Five blade files, no schema change. Safe to do live - no sale can be caught
  mid-flight by a template swap. Maintenance mode is optional.

    cd ~/domains/sales.eldogas.co.ke
    cp -r release-staging/eldogaspos/.   eldogaspos/
    cp -r release-staging/public_html/.  public_html/

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan view:clear
    php artisan config:clear && php artisan cache:clear && php artisan route:clear

  view:clear is the one that matters here - compiled blade is exactly what
  changed.

==============================================================================
STEP 5 - VERIFY
==============================================================================
  a. Open /pos/dashboard and hard-refresh (Ctrl+Shift+R) so the new service
     worker takes over. The top bar should read "EldoGas" - Eldo in dark,
     Gas in orange, no "POS" after it.

  b. The dark sidebar shows the company name with no "POS System" line
     underneath it.

  c. The browser tab reads "EldoGas", not "EldoGas POS".

  d. Log out. The login screen wordmark reads "EldoGas", not "Eldo_POS".

  e. Confirm nothing else moved - the POS still sells on one tap, and
     Rider Cylinders still opens from the sidebar.

  f. Re-run the check:

       cd ~/domains/sales.eldogas.co.ke/eldogaspos
       bash deploy-check.sh

     Expect: will update: 0   will add: 0   already current: 233

  g. Tidy up:

       cd ~/domains/sales.eldogas.co.ke && rm -rf release-staging

==============================================================================
IF SOMETHING GOES WRONG
==============================================================================
    cd ~/domains/sales.eldogas.co.ke
    ls -lh ~/backup-code-*.tar.gz          # the one from step 1
    tar -xzf ~/backup-code-YYYYMMDD-HHMM.tar.gz

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan view:clear && php artisan config:clear && php artisan route:clear

  The database is untouched by this release, so there is nothing to restore
  and no sale can be lost by rolling back.

==============================================================================
THE 5 FILES THIS RELEASE TOUCHES
==============================================================================
    resources/views/components/sidebar-layout.blade.php
    resources/views/layouts/app.blade.php
    resources/views/layouts/guest.blade.php
    resources/views/pos/dashboard.blade.php
    resources/views/welcome.blade.php

  Plus public_html/sw.js (cache name bumped to v5-20260918) and
  public_html/build/* (unchanged bytes, shipped for consistency).
