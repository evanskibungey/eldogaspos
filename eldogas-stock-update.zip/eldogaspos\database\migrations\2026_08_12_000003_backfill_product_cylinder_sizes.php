<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Cylinder size previously existed only as free text inside products.name
     * ("12kg Propane Cylinder"). This lifts it into the structured column.
     *
     * Detection is scoped to the cylinder categories rather than parsing every
     * product name, because unrelated products legitimately carry a kg figure -
     * "Fire Extinguisher (2kg)" is Safety Equipment, not a gas cylinder, and
     * must not become sellable-by-size stock.
     */
    public function up(): void
    {
        $cylinderCategoryIds = DB::table('categories')
            ->whereIn('name', ['Gas Cylinders', 'Refill Services'])
            ->pluck('id');

        if ($cylinderCategoryIds->isEmpty()) {
            return;
        }

        $products = DB::table('products')
            ->whereIn('category_id', $cylinderCategoryIds)
            ->whereNull('cylinder_size_kg')
            ->get(['id', 'name']);

        foreach ($products as $product) {
            $size = $this->parseSizeKg($product->name);

            if ($size !== null) {
                DB::table('products')
                    ->where('id', $product->id)
                    ->update(['cylinder_size_kg' => $size]);
            }
        }
    }

    public function down(): void
    {
        DB::table('products')->update(['cylinder_size_kg' => null]);
    }

    /**
     * Pull a kg figure out of a product name: "12kg", "12 kg", "12.5KG".
     */
    private function parseSizeKg(string $name): ?float
    {
        if (preg_match('/(\d+(?:\.\d+)?)\s*kg\b/i', $name, $matches)) {
            return (float) $matches[1];
        }

        return null;
    }
};
