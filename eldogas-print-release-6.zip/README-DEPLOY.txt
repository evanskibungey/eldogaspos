EldoGas - Print button, receipt on its own page, sales badge (release 6)
                                                                   2026-09-19
==============================================================================

Target:   sales.eldogas.co.ke   (cPanel)
App root: ~/domains/sales.eldogas.co.ke/eldogaspos
Web root: ~/domains/sales.eldogas.co.ke/public_html

Applies on top of RELEASE 5, which is what is live.

------------------------------------------------------------------------------
WHAT THIS CHANGES
------------------------------------------------------------------------------
1. A PRINT BUTTON ON EVERY PRODUCT TILE, beside Pick-up.
   Press it and the sale completes and the receipt prints, in one press.

   It replaces double-clicking the tile, which did not work. A double-click
   selected the product name instead of firing - the tile had no
   `user-select: none`, so the browser treated it as text. The double-click
   handler is removed entirely and the tile no longer reacts to one.

   A single tap on the tile still sells, exactly as before. The 450ms
   repeat-tap guard stays: a tile is a big target with no confirm step behind
   it, so an impatient second tap must not take money twice.

2. THE RECEIPT IS NOW ITS OWN PAGE, printed from a hidden iframe.

   THIS IS THE FIX FOR "2 SHEETS OF PAPER". The POS used to print by hiding
   the whole dashboard with `visibility: hidden` and revealing one div - but
   hidden elements still occupy layout, so the dashboard's full height kept
   paginating. Every receipt came out on two sheets.

   The receipt now lives at /pos/sales/{id}/receipt with nothing else on the
   page, so nothing else can paginate with it. It carries
   `@page { size: 57mm auto }`; `auto` is what stops the printer feeding a
   fixed page length and cutting the receipt mid-total.

   Pressing Print completes the sale, loads that page into an invisible
   iframe and the page prints itself. The cashier never leaves the POS and
   nothing flashes on screen.

3. THAT URL IS ALSO A REPRINT PAGE.
   Opened directly it renders with a Print button instead of ambushing
   whoever opened it with a print dialog. With ?autoprint=1 it prints itself.
   A cashier may reprint their own sales; an admin may reprint anyone's.

   209 lines of obsolete print CSS and the duplicate inline receipt are gone.
   Two templates for one document drift apart, and it was the hidden-div copy
   that produced the two-sheet printouts.

4. A "SALES" COUNT IN THE POS HEADER, between Riders and Inventory.

       Cylinders (1014)   Riders   Sales (11)   Inventory (6115)

   It counts today's sales and shows the day's total on hover. It uses the
   same rule as the admin Sales Overview - today, excluding voided - so the
   two screens cannot disagree about the same day.

   The number is LIVE. It is seeded from the server at page load and
   incremented per sale, because the POS screen never reloads between sales;
   a figure rendered once would be wrong by the second sale of the day. It
   increments only when a sale was actually made - a replayed idempotency key
   returns the existing sale and must not inflate the count.

   The badge is green rather than purple on purpose: the other two badges
   count stock on hand, this one counts money taken, and in purple it reads
   as a third stock figure at a glance.

   LIMITATION worth knowing at cash-up: voiding a sale happens on another
   screen, so the badge does not drop until the POS is reloaded. The
   server-side figure is always right - refresh and trust the new number.

------------------------------------------------------------------------------
THE PRINT DIALOG - READ THIS, IT IS NOT A CODE CHANGE
------------------------------------------------------------------------------
  This release does NOT stop Chrome's print dialog appearing. No web page can.
  Browsers block silent printing deliberately; otherwise any site could spray
  your printer. Cylinder management has always had the same dialog - its
  Print Receipt button is the same window.print() call.

  To get paper with no dialog, the TILL must be set up for it:

    1. Printers & scanners: turn OFF "Let Windows manage my default printer",
       then set the THERMAL PRINTER as the default. If this is skipped,
       kiosk printing silently sends every receipt to whatever is default -
       often "Microsoft Print to PDF", which saves files instead of printing.

    2. Make a desktop shortcut whose Target is:

         "C:\Program Files\Google\Chrome\Application\chrome.exe" --kiosk-printing --user-data-dir="C:\eldogas-pos-profile" --app=https://sales.eldogas.co.ke/pos/dashboard

       --user-data-dir matters: Chrome IGNORES --kiosk-printing if Chrome is
       already running, because a new window just joins the existing process.
       Its own profile guarantees a fresh process every time.

  Do this AFTER deploying this release, not before - on release 5 every sale
  would silently push two sheets of thermal paper with no dialog to cancel.

------------------------------------------------------------------------------
SOMETHING TO FIX IN SETTINGS (not done here on purpose)
------------------------------------------------------------------------------
  Settings currently hold:
      company_name  = "EldoGas POS"
      company_phone = "0700123456"      <- a placeholder, not a real number

  The receipt deliberately keeps printing the literals it has always printed,
  "Eldogas" and "+254724556855", rather than reading those settings. Wiring
  them in would put a dead phone number on every customer's receipt.

  Once both values are correct in Settings, the two lines at the top of
  resources/views/pos/receipts/thermal.blade.php can be switched to setting().
  There is a comment there saying so.

NO DATABASE CHANGES AT ALL
  No migrations, no new settings, no schema change. Nothing to migrate, and a
  database backup is not needed for this release.

ASSETS
  Stylesheet changes: app-8377ef03.css -> app-f895ced2.css. public_html must
  be copied in or the tiles and the new badge render unstyled.

  public_html/sw.js moves from eldogas-pos-v6-20260918 to v7-20260919. The
  worker precaches /pos/dashboard, so without this bump a till would keep the
  old screen and never show the Print button. Each till needs one reload.

DELIBERATELY NOT INCLUDED - do not add these
  .env                  the server keeps its own
  vendor/               no dependency changes
  database/seeders/     would duplicate the live catalogue if db:seed ran
  storage/              live runtime data
  public/hot            dev-server marker; shipping it breaks every asset URL
  public_html/index.php production's copy points at ../eldogaspos
  public_html/.htaccess cPanel may have added PHP-version handlers to it
  tests/, phpunit.xml   NEVER run tests on production

==============================================================================
STEP 1 - BACK UP THE CODE
==============================================================================
    cd ~/domains/sales.eldogas.co.ke
    tar --exclude='eldogaspos/vendor' --exclude='eldogaspos/node_modules' \
        --exclude='eldogaspos/storage/logs' \
        -czf ~/backup-code-$(date +%Y%m%d-%H%M).tar.gz eldogaspos public_html
    ls -lh ~/backup-code-*.tar.gz

  No database export needed - nothing in this release touches it.

==============================================================================
STEP 2 - UNPACK INTO A HOLDING FOLDER
==============================================================================
  Upload eldogas-print-release-6.zip to ~/domains/sales.eldogas.co.ke/ then:

    cd ~/domains/sales.eldogas.co.ke
    unzip -t eldogas-print-release-6.zip | tail -2

    rm -rf release-staging
    unzip -q eldogas-print-release-6.zip -d release-staging

    cp release-staging/eldogaspos/deploy-check.sh \
       release-staging/eldogaspos/baseline-manifest.txt \
       release-staging/eldogaspos/release-manifest.txt \
       eldogaspos/

==============================================================================
STEP 3 - THE CHECK  (read-only, changes nothing)
==============================================================================
    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    bash deploy-check.sh

  EXPECT EXACTLY:
      SAFE  will update: 4   will add: 1   already current: 230

  "RESULT: STOP"           -> someone edited files on the server since release
                              5. Send those files over to be merged first.
  "RESULT: CHECK INVALID"  -> wrong folder, or a manifest was damaged.
  "will add" is more than 1 -> you are not on release 5. Stop and ask.
  "RESULT: SAFE"           -> continue.

==============================================================================
STEP 4 - COPY IT IN
==============================================================================
  Templates, two controller methods and one route. No schema change, so this
  is safe to do live - no sale can be caught mid-flight by a template swap.

    cd ~/domains/sales.eldogas.co.ke
    cp -r release-staging/eldogaspos/.   eldogaspos/
    cp -r release-staging/public_html/.  public_html/

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan view:clear   && php artisan route:clear
    php artisan config:clear && php artisan cache:clear

  route:clear matters here - there is a NEW route (pos.sales.receipt), and a
  cached route table would 404 it.

==============================================================================
STEP 5 - VERIFY
==============================================================================
  a. Open /pos/dashboard and hard-refresh (Ctrl+Shift+R) so the new service
     worker takes over. Each tile now shows TWO buttons: Pick-up and Print.

  b. SELLING IS UNCHANGED. Single-tap a cheap item. One sale in Sales
     History, stock down by one, no printing.

  c. DOUBLE-CLICK DOES NOTHING NOW. Double-tap a tile. Expect exactly ONE
     sale, no text selection on the product name, and no print.

  d. PRINT. Press Print on a cheap item. The sale completes AND the print
     dialog appears (or paper comes out, if kiosk printing is already set up).

     THE IMPORTANT CHECK: the preview must say 1 sheet, not 2, and show only
     the narrow receipt - not the dashboard behind it.

  e. REPRINT. Sales History -> note a receipt id, then visit
     /pos/sales/<id>/receipt directly. It should render the receipt with a
     Print button and NOT print by itself.

  f. Confirm a cashier cannot reprint another cashier's sale (expect 403).

  g. THE SALES BADGE. The header shows Sales with today's count beside it.
     Note the number, sell one item, and confirm it goes up by exactly one
     WITHOUT reloading the page. Hover it to see the day's total.

     Then compare it against Admin -> Dashboard -> Sales Overview "Today's
     Sales". The two counts must match.

  h. Re-run the check:

       cd ~/domains/sales.eldogas.co.ke/eldogaspos
       bash deploy-check.sh

     Expect: will update: 0   will add: 0   already current: 235

  i. Tidy up:

       cd ~/domains/sales.eldogas.co.ke && rm -rf release-staging

  OPTIONAL TIDY - a dead file this release does not remove.
  A zip extract never deletes, so an orphaned template stays behind:

       app/Http/Controllers/Pos/receipts/thermal.blade.php

  It is a blade file sitting in a controllers directory, referenced by
  nothing, superseded by resources/views/pos/receipts/thermal.blade.php. It
  does no harm; remove it only if you want the tree tidy:

       rm ~/domains/sales.eldogas.co.ke/eldogaspos/app/Http/Controllers/Pos/receipts/thermal.blade.php

==============================================================================
IF SOMETHING GOES WRONG
==============================================================================
    cd ~/domains/sales.eldogas.co.ke
    ls -lh ~/backup-code-*.tar.gz          # the one from step 1
    tar -xzf ~/backup-code-YYYYMMDD-HHMM.tar.gz

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan view:clear && php artisan route:clear
    php artisan config:clear && php artisan cache:clear

  The database is untouched by this release, so there is nothing to restore
  and no sale can be lost by rolling back.

==============================================================================
THE 5 FILES THIS RELEASE TOUCHES
==============================================================================
  ADDED (1)
    resources/views/pos/receipts/thermal.blade.php   the standalone 57mm receipt

  UPDATED (4)
    app/Http/Controllers/Pos/PosController.php       today's sales stats
    app/Http/Controllers/Pos/SaleController.php      receipt() + the 403 rule
    resources/views/pos/dashboard.blade.php          Print button, iframe print,
                                                     Sales badge, dblclick and
                                                     209 lines of old print CSS
                                                     removed
    routes/web.php                                   pos.sales.receipt

  Plus public_html/build/* (new stylesheet app-f895ced2.css) and
  public_html/sw.js (cache name bumped to v7-20260919).
