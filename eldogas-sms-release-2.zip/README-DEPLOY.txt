EldoGas POS - SMS copy update (release 2)                          2026-09-14
==============================================================================

Target:   sales.eldogas.co.ke   (cPanel)
App root: ~/domains/sales.eldogas.co.ke/eldogaspos
Web root: ~/domains/sales.eldogas.co.ke/public_html

------------------------------------------------------------------------------
WHAT THIS CHANGES - three PHP files, nothing else
------------------------------------------------------------------------------
  app/Services/Sms/ReceiptMessage.php
      Prices removed from the POS sale receipt and the cylinder drop-off SMS.
      Prices move, and a figure sitting in someone's inbox outlives the price
      list it came from - the drop-off worst of all, since it is quoted when
      the cylinder is left but paid when it is collected.
      The credit receipt keeps "Balance:" (what is owed, not a price), and the
      payment confirmation keeps its amount (money actually received).

  app/Services/Sms/TalkSasaClient.php
      Store TalkSasa's reference against each message. It returns the id as
      `queue_uid`; the client looked for `uid`/`message_id`/`id`, so the
      gateway_uid column was being left empty. Nothing was lost - the whole
      response is saved in sms_logs.response - but the column is now filled.

  routes/web.php
      /app refuses to redirect to itself. Setting "App store URL" to the short
      link made it loop, which customers saw as ERR_TOO_MANY_REDIRECTS.

NO DATABASE CHANGES AT ALL
  No migrations, no new settings, no schema changes. Nothing to migrate and
  nothing to back up on the database side. Rolling back is purely a code
  restore.

NO ASSET CHANGES
  No blade, CSS or JavaScript changed, so the service worker cache version is
  deliberately NOT bumped - tills have nothing new to pick up.

DELIBERATELY NOT INCLUDED - do not add these
  .env                  the server keeps its own
  vendor/               no dependency changes
  database/seeders/     would duplicate the live catalogue if db:seed ran
  storage/              live runtime data
  public_html/index.php production's copy points at ../eldogaspos
  public_html/.htaccess cPanel may have added PHP-version handlers to it
  tests/, phpunit.xml   NEVER run tests on production

==============================================================================
STEP 1 - BACK UP THE CODE
==============================================================================
    cd ~/domains/sales.eldogas.co.ke
    tar --exclude='eldogaspos/vendor' --exclude='eldogaspos/node_modules' \
        --exclude='eldogaspos/storage/logs' \
        -czf ~/backup-code-$(date +%Y%m%d-%H%M).tar.gz eldogaspos public_html
    ls -lh ~/backup-code-*.tar.gz

  A database export is not needed for this release - nothing touches it.

==============================================================================
STEP 2 - UNPACK INTO A HOLDING FOLDER
==============================================================================
  Upload eldogas-sms-release-2.zip to ~/domains/sales.eldogas.co.ke/ then:

    cd ~/domains/sales.eldogas.co.ke
    rm -rf release-staging
    unzip -q eldogas-sms-release-2.zip -d release-staging

    cp release-staging/eldogaspos/deploy-check.sh \
       release-staging/eldogaspos/baseline-manifest.txt \
       release-staging/eldogaspos/release-manifest.txt \
       eldogaspos/

==============================================================================
STEP 3 - THE CHECK  (read-only, changes nothing)
==============================================================================
    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    bash deploy-check.sh

  EXPECT EXACTLY:
      SAFE  will update: 3   will add: 0   already current: 219

  "RESULT: STOP"           -> someone edited files on the server since the last
                              release. Send those files over to be merged first.
  "RESULT: CHECK INVALID"  -> wrong folder, or a manifest was damaged.
  "RESULT: SAFE"           -> continue.

  If "will update" is more than 3, stop and ask - this release should touch
  only ReceiptMessage.php, TalkSasaClient.php and routes/web.php.

==============================================================================
STEP 4 - COPY IT IN
==============================================================================
  Three PHP files with no schema change: brief, and safe to do live. Use
  maintenance mode if you would rather be certain no sale is mid-request.

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan down --secret="eldogas-deploy-check"      # optional

    cd ~/domains/sales.eldogas.co.ke
    cp -r release-staging/eldogaspos/.   eldogaspos/
    cp -r release-staging/public_html/.  public_html/

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan config:clear && php artisan cache:clear
    php artisan view:clear   && php artisan route:clear
    php artisan up                                        # if you used down

==============================================================================
STEP 5 - VERIFY
==============================================================================
  a. The redirect still works and cannot loop:

       curl -sI https://sales.eldogas.co.ke/app | grep -iE "^HTTP|^location"

     Expect 302 to the Play Store. (Nobody should be using this link any more -
     new messages carry https://eldogas.ke/get - but messages already sent
     point here, so it must keep working.)

  b. Send yourself a test transaction and read the SMS. The receipt should
     name the product and show NO price.

  c. SMS -> History: the newest row should be Sent.

  d. Re-run the check - everything should now be current:

       cd ~/domains/sales.eldogas.co.ke/eldogaspos
       bash deploy-check.sh

     Expect: will update: 0   will add: 0   already current: 222

  e. Tidy up:

       cd ~/domains/sales.eldogas.co.ke && rm -rf release-staging

==============================================================================
IF SOMETHING GOES WRONG
==============================================================================
    cd ~/domains/sales.eldogas.co.ke
    ls -lh ~/backup-code-*.tar.gz          # the one from step 1
    tar -xzf ~/backup-code-YYYYMMDD-HHMM.tar.gz

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan config:clear && php artisan view:clear && php artisan route:clear
    php artisan up

  The database is untouched by this release, so there is nothing to restore
  and no sale can be lost by rolling back.
