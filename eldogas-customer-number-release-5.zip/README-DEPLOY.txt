EldoGas - customer number on pick-up, plus the branding change (release 5)
                                                                   2026-09-18
==============================================================================

Target:   sales.eldogas.co.ke   (cPanel)
App root: ~/domains/sales.eldogas.co.ke/eldogaspos
Web root: ~/domains/sales.eldogas.co.ke/public_html

Applies on top of RELEASE 4, which is what is live. If release 4 is not on the
server, stop - deploy that first, or the check in step 3 will refuse this one.

------------------------------------------------------------------------------
WHAT THIS ADDS - the customer's number on a pick-up
------------------------------------------------------------------------------
  In the POS pick-up modal, every rider row now has a small phone-icon button
  on its right-hand edge.

      Tap the ROW            assigns immediately. Exactly as before.
      Tap the PHONE ICON     opens a field for the customer's number, then
                             Send assigns and puts that number in the rider's
                             text so they can call ahead.

  It is optional in the strict sense. Leaving it alone, opening it and leaving
  it empty, or typing only spaces all behave exactly like an ordinary pick-up.
  Nothing about the existing one-tap flow changes.

  The number is accepted in any spelling - 0722884226, 254722884226,
  +254 722 884 226 - and stored normalised, like every other number in the
  system. The rider is texted it in DIALABLE form, because a rider reading
  "254722884226" off a text has to edit it before it will connect:

      Pick-up #RDR20260918001
      3x 13kg Gas Cylinder
      Customer: 0722884226

  Still one billed segment, even with a full item list. Without a number the
  text is unchanged from what you are sending today.

  A number that cannot be dialled (too short, not a Kenyan mobile prefix)
  refuses the WHOLE pick-up - no cylinders reserved, no SMS sent - and the
  field stays open on screen with the typo still in it so it can be corrected.
  Refusing rather than silently dropping it matters: a rider who is told a
  customer number will ring it, and a wrong one wastes the delivery.

  The number also shows in Rider Cylinders, under the rider's own number on
  each open order, so the shop can see where a bike is headed.

------------------------------------------------------------------------------
DATABASE CHANGES - one migration, additive
------------------------------------------------------------------------------
    2026_09_18_000005_add_customer_phone_to_rider_allocations
        Adds one nullable column to `rider_allocations`. No existing row is
        read or written; every pick-up taken so far simply has NULL there.
        `rider_allocations` is a small, new table, so the ALTER is instant.

  Take the code backup in step 1. A database export is sensible but this
  migration cannot lose data - it only adds a column.

  NEVER on production: migrate:fresh, migrate:refresh, migrate:reset,
  db:wipe, db:seed.

------------------------------------------------------------------------------
ASSETS
------------------------------------------------------------------------------
  The stylesheet changed: app-646f2857.css -> app-8377ef03.css. public_html
  must be copied in, or the modal renders unstyled.

  public_html/sw.js moves from eldogas-pos-v5-20260918 (release 4) to
  v6-20260918, so the till cache is evicted and the new modal is picked up.
  Each till still needs one reload after deploying.

DELIBERATELY NOT INCLUDED - do not add these
  .env                  the server keeps its own
  vendor/               no dependency changes
  database/seeders/     would duplicate the live catalogue if db:seed ran
  storage/              live runtime data
  public/hot            dev-server marker; shipping it breaks every asset URL
  public_html/index.php production's copy points at ../eldogaspos
  public_html/.htaccess cPanel may have added PHP-version handlers to it
  tests/, phpunit.xml   NEVER run tests on production

==============================================================================
STEP 1 - BACK UP THE CODE
==============================================================================
    cd ~/domains/sales.eldogas.co.ke
    tar --exclude='eldogaspos/vendor' --exclude='eldogaspos/node_modules' \
        --exclude='eldogaspos/storage/logs' \
        -czf ~/backup-code-$(date +%Y%m%d-%H%M).tar.gz eldogaspos public_html
    ls -lh ~/backup-code-*.tar.gz

==============================================================================
STEP 2 - UNPACK INTO A HOLDING FOLDER
==============================================================================
  Upload eldogas-customer-number-release-5.zip to
  ~/domains/sales.eldogas.co.ke/ then:

    cd ~/domains/sales.eldogas.co.ke
    unzip -t eldogas-customer-number-release-5.zip | tail -2

    rm -rf release-staging
    unzip -q eldogas-customer-number-release-5.zip -d release-staging

    cp release-staging/eldogaspos/deploy-check.sh \
       release-staging/eldogaspos/baseline-manifest.txt \
       release-staging/eldogaspos/release-manifest.txt \
       eldogaspos/

==============================================================================
STEP 3 - THE CHECK  (read-only, changes nothing)
==============================================================================
    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    bash deploy-check.sh

  EXPECT EXACTLY:
      SAFE  will update: 7   will add: 1   already current: 226

  The baseline in this release is RELEASE 4, so a DANGER line here means a
  genuine server-side edit. Treat it as one - do not wave it through.

  "RESULT: STOP"           -> someone edited files on the server since release
                              4. Send those files over to be merged first.
  "RESULT: CHECK INVALID"  -> wrong folder, or a manifest was damaged.
  "will update" is 11      -> release 4 is NOT on this server after all.
                              Deploy eldogas-branding-release-4.zip first.
  "RESULT: SAFE"           -> continue.

==============================================================================
STEP 4 - COPY IT IN AND MIGRATE
==============================================================================
  One additive column and some templates. Brief enough to do live, but
  maintenance mode costs nothing if you would rather be certain.

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan down --secret="eldogas-deploy-check"      # optional

    cd ~/domains/sales.eldogas.co.ke
    cp -r release-staging/eldogaspos/.   eldogaspos/
    cp -r release-staging/public_html/.  public_html/

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan migrate --force

  Expect one line ending DONE:
      2026_09_18_000005_add_customer_phone_to_rider_allocations ..... DONE

    php artisan config:clear && php artisan cache:clear
    php artisan view:clear   && php artisan route:clear
    php artisan up                                        # if you used down

==============================================================================
STEP 5 - VERIFY
==============================================================================
  a. Open /pos/dashboard and hard-refresh (Ctrl+Shift+R) so the new service
     worker takes over.

  b. Press Pick-up on a product. Each rider row now has a phone icon on its
     right edge.

  c. THE OLD FLOW STILL WORKS. Tap a rider's NAME (not the icon). It should
     assign immediately, exactly as it does today, and the rider's text should
     have no "Customer:" line.

  d. THE NEW FLOW. Press Pick-up again, tap the PHONE ICON on a rider, type a
     number you can read, press Send. Check the text arrives reading
     "Customer: 07xx xxx xxx" in dialable form.

  e. A BAD NUMBER IS REFUSED. Press the icon, type 12345, press Send. Expect a
     red message under the field, the modal still open, and NO SMS. Confirm in
     Rider Cylinders that no new order was created and stock did not move.

  f. Rider Cylinders shows the customer number under the rider's own number on
     the order from (d).

  g. Re-run the check:

       cd ~/domains/sales.eldogas.co.ke/eldogaspos
       bash deploy-check.sh

     Expect: will update: 0   will add: 0   already current: 234

  h. Tidy up:

       cd ~/domains/sales.eldogas.co.ke && rm -rf release-staging

==============================================================================
IF SOMETHING GOES WRONG
==============================================================================
  ROLL BACK THE CODE, NOT THE DATABASE.

    cd ~/domains/sales.eldogas.co.ke
    ls -lh ~/backup-code-*.tar.gz          # the one from step 1
    tar -xzf ~/backup-code-YYYYMMDD-HHMM.tar.gz

    cd ~/domains/sales.eldogas.co.ke/eldogaspos
    php artisan config:clear && php artisan view:clear && php artisan route:clear
    php artisan up

  Leave the migration in place. The restored release-3 code never reads
  rider_allocations.customer_phone and the column is nullable, so pick-ups
  carry on working. Restoring a database dump would erase every sale taken
  since the backup, which is far worse than one idle column.

==============================================================================
THE 8 FILES THIS RELEASE TOUCHES
==============================================================================
  ADDED (1)
    database/migrations/2026_09_18_000005_add_customer_phone_to_rider_allocations.php

  UPDATED (7)
    app/Http/Controllers/Admin/RiderController.php   accepts + validates it
    app/Models/RiderAllocation.php                   new fillable column
    app/Services/Sms/PhoneNumber.php                 local() dialable format
    app/Services/Sms/RiderMessage.php                the "Customer:" line
    resources/views/admin/riders/index.blade.php     shows it on open orders
    resources/views/admin/riders/show.blade.php      shows it in rider history
    resources/views/pos/dashboard.blade.php          the icon, field and Send

  Plus public_html/build/* (new stylesheet app-8377ef03.css) and
  public_html/sw.js (cache name bumped to v6-20260918).
